package com.raylan.studioai

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.studioai.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RaylanStudioRobolectricTest {

    @Test
    fun `app metadata and SecurityGuard verify intact on MainActivity`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("com.raylan.studioai", context.packageName)
        assertEquals("Raylan Studio AI", context.getString(R.string.app_name))

        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        val result = SecurityGuard.verifyIntegrity(activity)
        assertTrue("Expected intact MainActivity, got: ${result.reason}", result.isIntact)
    }
}
