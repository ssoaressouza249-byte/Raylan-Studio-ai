package com.raylan.studioai

import com.raylan.studioai.export.ProjectZipExporter
import com.raylan.studioai.generator.GeminiAppGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class StudioCoreUnitTest {

    @Test
    fun `parseGeneratedFiles extracts multiple delimited files cleanly`() {
        val raw = """
            ===FILE: settings.gradle.kts===
            rootProject.name = "DemoApp"
            ===END_FILE===

            ===FILE: app/src/main/java/com/demo/MainActivity.kt===
            ```kotlin
            package com.demo
            class MainActivity
            ```
            ===END_FILE===
        """.trimIndent()

        val files = GeminiAppGenerator.parseGeneratedFiles(raw)
        assertEquals(2, files.size)
        assertEquals("settings.gradle.kts", files[0].path)
        assertEquals("rootProject.name = \"DemoApp\"", files[0].content)
        assertEquals("app/src/main/java/com/demo/MainActivity.kt", files[1].path)
        assertTrue(files[1].content.startsWith("package com.demo"))
    }

    @Test
    fun `buildZipBytes preserves directory paths and contents`() {
        val raw = """
            ===FILE: .github/workflows/build.yml===
            name: Build
            ===END_FILE===
            ===FILE: app/build.gradle.kts===
            plugins {}
            ===END_FILE===
        """.trimIndent()

        val files = GeminiAppGenerator.parseGeneratedFiles(raw)
        val zipBytes = ProjectZipExporter.buildZipBytes(files)

        val entries = mutableListOf<String>()
        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                entries.add(entry.name)
                entry = zis.nextEntry
            }
        }

        assertEquals(listOf(".github/workflows/build.yml", "app/build.gradle.kts"), entries)
        assertEquals("mira-flutuante-pro", ProjectZipExporter.slugifyAppName("Mira Flutuante Pró!"))
    }
}
