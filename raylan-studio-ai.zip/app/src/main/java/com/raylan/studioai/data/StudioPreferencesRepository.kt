package com.raylan.studioai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.raylan.studioai.model.GeneratedFile
import com.raylan.studioai.model.GeneratedProject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.studioDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "raylan_studio_prefs"
)

class StudioPreferencesRepository(private val context: Context) {

    private object Keys {
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val PROJECTS_HISTORY = stringPreferencesKey("projects_history_json")
    }

    val apiKeyFlow: Flow<String> = context.studioDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                emit(emptyPreferences())
            }
        }
        .map { prefs ->
            prefs[Keys.GEMINI_API_KEY].orEmpty()
        }

    val projectsFlow: Flow<List<GeneratedProject>> = context.studioDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                emit(emptyPreferences())
            }
        }
        .map { prefs ->
            decodeProjects(prefs[Keys.PROJECTS_HISTORY].orEmpty())
        }

    suspend fun saveApiKey(apiKey: String): Result<Unit> = runCatching {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.GEMINI_API_KEY] = apiKey.trim()
        }
        Unit
    }

    suspend fun saveProject(project: GeneratedProject): Result<Unit> = runCatching {
        context.studioDataStore.edit { prefs ->
            val current = decodeProjects(prefs[Keys.PROJECTS_HISTORY].orEmpty()).toMutableList()
            current.removeAll { it.id == project.id }
            current.add(0, project)
            // Mantém histórico leve com até 25 projetos recentes
            val trimmed = current.take(25)
            prefs[Keys.PROJECTS_HISTORY] = encodeProjects(trimmed)
        }
        Unit
    }

    suspend fun deleteProject(projectId: String): Result<Unit> = runCatching {
        context.studioDataStore.edit { prefs ->
            val current = decodeProjects(prefs[Keys.PROJECTS_HISTORY].orEmpty())
                .filterNot { it.id == projectId }
            prefs[Keys.PROJECTS_HISTORY] = encodeProjects(current)
        }
        Unit
    }

    private fun encodeProjects(projects: List<GeneratedProject>): String {
        val array = JSONArray()
        projects.forEach { project ->
            val obj = JSONObject().apply {
                put("id", project.id)
                put("appName", project.appName)
                put("prompt", project.prompt)
                put("createdAtMillis", project.createdAtMillis)
                put("capabilities", JSONArray(project.capabilities))
                val filesArray = JSONArray()
                project.files.forEach { file ->
                    filesArray.put(
                        JSONObject().apply {
                            put("path", file.path)
                            put("content", file.content)
                        }
                    )
                }
                put("files", filesArray)
            }
            array.put(obj)
        }
        return array.toString()
    }

    private fun decodeProjects(rawJson: String): List<GeneratedProject> {
        if (rawJson.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(rawJson)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val appName = obj.optString("appName")
                    val prompt = obj.optString("prompt")
                    val createdAt = obj.optLong("createdAtMillis", 0L)

                    val capArray = obj.optJSONArray("capabilities") ?: JSONArray()
                    val caps = buildList {
                        for (c in 0 until capArray.length()) {
                            capArray.optString(c).takeIf { it.isNotBlank() }?.let(::add)
                        }
                    }

                    val filesArray = obj.optJSONArray("files") ?: JSONArray()
                    val files = buildList {
                        for (f in 0 until filesArray.length()) {
                            val fileObj = filesArray.optJSONObject(f) ?: continue
                            val path = fileObj.optString("path")
                            val content = fileObj.optString("content")
                            if (path.isNotBlank()) {
                                add(GeneratedFile(path = path, content = content))
                            }
                        }
                    }

                    if (id.isNotBlank() && appName.isNotBlank() && files.isNotEmpty()) {
                        add(
                            GeneratedProject(
                                id = id,
                                appName = appName,
                                prompt = prompt,
                                files = files,
                                createdAtMillis = createdAt,
                                capabilities = caps
                            )
                        )
                    }
                }
            }
        }.getOrDefault(emptyList())
    }
}
