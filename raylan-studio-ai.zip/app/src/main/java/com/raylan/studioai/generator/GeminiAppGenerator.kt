package com.raylan.studioai.generator

import com.raylan.studioai.model.GeneratedFile
import com.raylan.studioai.model.GeneratedProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object GeminiAppGenerator {

    private const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    private const val MODEL_ID = "gemini-2.5-flash"
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .callTimeout(210, TimeUnit.SECONDS)
            .build()
    }

    private val ANDROID_ARCHITECT_SYSTEM_INSTRUCTION = """
Você é o Cérebro Arquiteto Android Sênior do Raylan Studio AI.
Sua missão é gerar projetos Android nativos 100% completos, reais, organizados e compiláveis imediatamente no GitHub Actions.

REGRAS TÉCNICAS OBRIGATÓRIAS DE ARQUITETURA E BUILD:
1. Linguagem e UI: Kotlin puro + Jetpack Compose + Material Design 3.
2. SDKs e Gradle (Kotlin DSL):
   - compileSdk = 36, targetSdk = 36, minSdk = 26, JavaVersion.VERSION_17.
   - NÃO use Firebase, NÃO use `firebase-ai`, NÃO use plugin `secrets`, NÃO use arquivos `.ttf` externos (use sempre `FontFamily.Default` e `FontFamily.Monospace`).
   - Todas as chamadas de rede, IPC ou I/O de arquivos devem ser protegidas com `runCatching`.
   - Use `settings.gradle.kts` com `google()` e `mavenCentral()`, `build.gradle.kts` (raiz) e `app/build.gradle.kts`.
   - Use versões modernas e compatíveis no Gradle (AGP 8.9.1 ou 9.1.1, Kotlin 2.1.20+, Compose BOM 2025.02.00+, `androidx.activity:activity-compose`, `androidx.compose.material3:material3`, `androidx.compose.material:material-icons-extended`).
   - Sempre gere o arquivo `.github/workflows/build.yml` configurado com `ubuntu-latest`, `actions/checkout@v4`, `actions/setup-java@v4` (JDK 17, `temurin`), `gradle/actions/setup-gradle@v4` (`gradle-version: 9.3.1`), `gradle assembleDebug --no-daemon` e `actions/upload-artifact@v4`.
   - Sempre gere `app/src/main/res/values/strings.xml`, `app/src/main/res/values/themes.xml` e `app/src/main/AndroidManifest.xml` completos e válidos.

SUPORTE AUTOMÁTICO A RECURSOS AVANÇADOS (QUANDO PEDIDOS NO PROMPT):
A) SHIZUKU:
   - Adicione `implementation("dev.rikka.shizuku:api:13.1.5")` e `implementation("dev.rikka.shizuku:provider:13.1.5")` no `app/build.gradle.kts`, e habilite `buildFeatures { compose = true; aidl = true }`.
   - No `AndroidManifest.xml`, declare `<uses-permission android:name="moe.shizuku.manager.permission.API_V23" />` e o `<provider android:name="rikka.shizuku.ShizukuProvider" android:authorities="${'$'}{applicationId}.shizuku" android:multiprocess="false" android:enabled="true" android:exported="true" android:permission="android.permission.INTERACT_BETWEEN_USERS_FULL" />`.
   - Crie `app/src/main/aidl/<pacote>/IShellService.aidl` com métodos reais para executar comandos shell (`String execCommand(String command); void destroy();`) e um `ShizukuUserService.kt` + gerenciador de permissão/binding com `Shizuku.UserServiceArgs`.

B) SOBREPOSIÇÃO DE TELA (OVERLAY):
   - Declare `<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />`, `FOREGROUND_SERVICE` e `FOREGROUND_SERVICE_SPECIAL_USE`.
   - Registre o `ForegroundService` no `AndroidManifest.xml` com `android:foregroundServiceType="specialUse"` e `<property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="screen_overlay_hud" />`.
   - Implemente o `OverlayService.kt` usando `WindowManager` com `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY`, `FLAG_NOT_TOUCHABLE` (quando for mira/HUD pass-through), `FLAG_NOT_FOCUSABLE`, `FLAG_LAYOUT_IN_SCREEN` e `PixelFormat.TRANSLUCENT`, além de notificação persistente com `NotificationChannel` e fluxo seguro para solicitar `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`.

C) SERVIÇO DE ACESSIBILIDADE (ACCESSIBILITY SERVICE):
   - Crie uma subclasse real de `AccessibilityService` configurada no `AndroidManifest.xml` com `android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"`, `<intent-filter><action android:name="android.accessibilityservice.AccessibilityService" /></intent-filter>` e `<meta-data android:name="android.accessibilityservice" android:resource="@xml/accessibility_service_config" />`.
   - Crie `app/src/main/res/xml/accessibility_service_config.xml` completo com `accessibilityEventTypes`, `accessibilityFeedbackType`, `canRetrieveWindowContent="true"`, `canPerformGestures="true"` e `accessibilityFlags`.

FORMATO DE SAÍDA ESTRITO (SIGA EXATAMENTE):
NÃO escreva explicações longas fora dos blocos. Entregue TODOS os arquivos completos usando EXCLUSIVAMENTE os delimitadores abaixo:

===FILE: caminho/exato/do/arquivo===
conteudo completo do arquivo sem omissões ou "// TODO"
===END_FILE===

Certifique-se de incluir todos os arquivos necessários para o projeto compilar do zero sem erros!
    """.trimIndent()

    private val PROMPT_ENHANCER_SYSTEM_INSTRUCTION = """
Você é um Engenheiro de Produto e Arquiteto Android Sênior.
Reescreva o pedido curto do usuário em um prompt técnico completo, objetivo e pronto para gerar um aplicativo Android nativo em Kotlin + Jetpack Compose (compileSdk 36, minSdk 26).
Especifique claramente:
- Telas principais, fluxos de navegação e estética Material 3.
- Permissões e APIs Android necessárias (se envolver root/ADB sem root, detalhe Shizuku 13.1.5 + IShellService.aidl; se envolver janela flutuante/mira/HUD, detalhe SYSTEM_ALERT_WINDOW + ForegroundService specialUse + WindowManager com FLAG_NOT_TOUCHABLE; se envolver automação/toques/leitura de tela, detalhe AccessibilityService + XML config).
- Persistência ou estado em ViewModel/StateFlow com tratamento de erros `runCatching`.
Responda APENAS com o prompt melhorado em português claro, sem introduções ou markdown excessivo.
    """.trimIndent()

    suspend fun testApiKey(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = apiKey.trim()
            require(cleanKey.isNotEmpty()) { "Informe uma chave API válida antes de testar." }

            val request = Request.Builder()
                .url("$GEMINI_BASE_URL/models/$MODEL_ID")
                .addHeader("x-goog-api-key", cleanKey)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = extractGeminiError(bodyString, response.code)
                    error(errorMsg)
                }
                val json = JSONObject(bodyString)
                val displayName = json.optString("displayName").ifBlank { MODEL_ID }
                "Chave válida! Conectado ao modelo $displayName."
            }
        }
    }

    suspend fun enhancePrompt(
        apiKey: String,
        appName: String,
        roughPrompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = apiKey.trim()
            require(cleanKey.isNotEmpty()) {
                "Configure sua Chave API do Google AI Studio na aba 'API & Criador'."
            }
            require(roughPrompt.isNotBlank()) {
                "Descreva primeiro uma ideia de aplicativo para poder melhorá-la."
            }

            val userMessage = buildString {
                if (appName.isNotBlank()) {
                    append("Nome do App: ").append(appName.trim()).append("\n")
                }
                append("Ideia inicial: ").append(roughPrompt.trim())
            }

            val text = executeGenerateContent(
                apiKey = cleanKey,
                systemInstruction = PROMPT_ENHANCER_SYSTEM_INSTRUCTION,
                userPrompt = userMessage,
                temperature = 0.4,
                maxOutputTokens = 2048
            )
            text.trim().ifBlank { error("A IA não retornou um prompt melhorado.") }
        }
    }

    suspend fun generateFullProject(
        apiKey: String,
        appName: String,
        prompt: String
    ): Result<GeneratedProject> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanKey = apiKey.trim()
            require(cleanKey.isNotEmpty()) {
                "Configure sua Chave API do Google AI Studio na aba 'API & Criador'."
            }
            val finalAppName = appName.trim().ifBlank { "MeuAppRaylan" }
            require(prompt.isNotBlank()) {
                "Escreva o prompt descrevendo o aplicativo que deseja criar."
            }

            val sanitizedPackageSlug = finalAppName.lowercase()
                .replace(Regex("[^a-z0-9]"), "")
                .ifBlank { "app" }
                .take(16)

            val fullUserPrompt = """
Nome do Aplicativo: $finalAppName
Pacote sugerido: com.raylan.generated.$sanitizedPackageSlug

Especificação do Usuário:
${prompt.trim()}

Gere o projeto Android completo agora usando ===FILE: caminho=== e ===END_FILE=== para cada arquivo, incluindo Gradle, Manifesto, recursos, código Kotlin/Compose e .github/workflows/build.yml.
            """.trimIndent()

            val rawOutput = executeGenerateContent(
                apiKey = cleanKey,
                systemInstruction = ANDROID_ARCHITECT_SYSTEM_INSTRUCTION,
                userPrompt = fullUserPrompt,
                temperature = 0.2,
                maxOutputTokens = 65536
            )

            val parsedFiles = parseGeneratedFiles(rawOutput)
            require(parsedFiles.isNotEmpty()) {
                "Não foi possível extrair os arquivos ===FILE: ...=== da resposta da IA. Tente refinar o prompt."
            }

            GeneratedProject(
                id = UUID.randomUUID().toString(),
                appName = finalAppName,
                prompt = prompt.trim(),
                files = parsedFiles,
                createdAtMillis = System.currentTimeMillis(),
                capabilities = detectCapabilities(prompt, parsedFiles)
            )
        }
    }

    private fun executeGenerateContent(
        apiKey: String,
        systemInstruction: String,
        userPrompt: String,
        temperature: Double,
        maxOutputTokens: Int
    ): String {
        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().apply {
                    put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemInstruction))
                    )
                }
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", userPrompt))
                        )
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", temperature)
                    put("maxOutputTokens", maxOutputTokens)
                }
            )
        }

        val request = Request.Builder()
            .url("$GEMINI_BASE_URL/models/$MODEL_ID:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                error(extractGeminiError(bodyString, response.code))
            }

            val json = JSONObject(bodyString)
            val candidates = json.optJSONArray("candidates")
                ?: error("Resposta vazia da API Gemini.")
            if (candidates.length() == 0) {
                error("Nenhum resultado retornado pela API Gemini.")
            }

            val parts = candidates.getJSONObject(0)
                .optJSONObject("content")
                ?.optJSONArray("parts")
                ?: error("Conteúdo ausente na resposta da API Gemini.")

            return buildString {
                for (i in 0 until parts.length()) {
                    val partText = parts.optJSONObject(i)?.optString("text").orEmpty()
                    append(partText)
                }
            }
        }
    }

    private fun extractGeminiError(body: String, httpCode: Int): String {
        val parsedMessage = runCatching {
            JSONObject(body).optJSONObject("error")?.optString("message")
        }.getOrNull()
        return if (!parsedMessage.isNullOrBlank()) {
            "Erro Gemini ($httpCode): $parsedMessage"
        } else {
            "Falha HTTP $httpCode ao chamar a API Gemini."
        }
    }

    fun parseGeneratedFiles(rawOutput: String): List<GeneratedFile> {
        val pattern = Regex(
            pattern = """===FILE:\s*(.+?)\s*===\r?\n(.*?)\r?\n===END_FILE===""",
            options = setOf(RegexOption.DOT_MATCHES_ALL)
        )

        val uniqueFiles = LinkedHashMap<String, GeneratedFile>()
        pattern.findAll(rawOutput).forEach { match ->
            val rawPath = match.groupValues[1].trim()
            val normalizedPath = sanitizeRelativePath(rawPath)
            if (normalizedPath.isNotBlank()) {
                val cleanedContent = stripOuterCodeFence(match.groupValues[2])
                uniqueFiles[normalizedPath] = GeneratedFile(
                    path = normalizedPath,
                    content = cleanedContent
                )
            }
        }
        return uniqueFiles.values.toList()
    }

    private fun sanitizeRelativePath(path: String): String {
        val segments = path.replace('\\', '/')
            .trim()
            .trimStart('/')
            .split('/')
            .filter { it.isNotBlank() && it != "." && it != ".." }
        return segments.joinToString("/")
    }

    private fun stripOuterCodeFence(rawContent: String): String {
        val trimmed = rawContent.trim('\r', '\n')
        val lines = trimmed.lines()
        if (lines.size >= 2 &&
            lines.first().trimStart().startsWith("```") &&
            lines.last().trim() == "```"
        ) {
            return lines.subList(1, lines.size - 1).joinToString("\n")
        }
        return trimmed
    }

    private fun detectCapabilities(prompt: String, files: List<GeneratedFile>): List<String> {
        val combined = (prompt + "\n" + files.joinToString("\n") { it.path + "\n" + it.content })
            .lowercase()
        return buildList {
            if ("shizuku" in combined || "ishhellservice" in combined || "ishellservice" in combined) {
                add("Shizuku")
            }
            if ("system_alert_window" in combined || "overlay" in combined || "windowmanager" in combined) {
                add("Overlay")
            }
            if ("accessibilityservice" in combined || "bind_accessibility_service" in combined) {
                add("Acessibilidade")
            }
            if ("compose" in combined) {
                add("Compose")
            }
            if (files.any { it.path.contains(".github/workflows") }) {
                add("GitHub CI")
            }
        }
    }
}
