package com.raylan.studioai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.raylan.studioai.model.GeneratedFile
import com.raylan.studioai.model.GeneratedProject
import com.raylan.studioai.ui.StudioUiState
import com.raylan.studioai.ui.components.GeneratedFileRow
import com.raylan.studioai.ui.components.RaylanStudioFooter
import com.raylan.studioai.ui.components.StatusBanner
import com.raylan.studioai.ui.components.StudioCard
import com.raylan.studioai.ui.theme.DangerRed
import com.raylan.studioai.ui.theme.EmeraldAccent
import com.raylan.studioai.ui.theme.SkyBlueAccent
import com.raylan.studioai.ui.theme.SlateBorder
import com.raylan.studioai.ui.theme.SlateCardBg
import com.raylan.studioai.ui.theme.SoftBlackBg
import com.raylan.studioai.ui.theme.TextMuted
import com.raylan.studioai.ui.theme.TextPrimary
import com.raylan.studioai.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProjectsHistoryScreen(
    uiState: StudioUiState,
    onInspectProject: (GeneratedProject) -> Unit,
    onDismissProjectModal: () -> Unit,
    onOpenFile: (GeneratedFile) -> Unit,
    onExportZip: (GeneratedProject) -> Unit,
    onLoadInEditor: (GeneratedProject) -> Unit,
    onDeleteProject: (String) -> Unit,
    onDismissStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormatter = remember {
        SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale.getDefault())
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (!uiState.statusMessage.isNullOrBlank()) {
            item(key = "history_status") {
                StatusBanner(
                    message = uiState.statusMessage,
                    isError = uiState.isStatusError,
                    onDismiss = onDismissStatus,
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        }

        if (uiState.historyProjects.isEmpty()) {
            item(key = "empty_history") {
                StudioCard(modifier = Modifier.widthIn(max = 720.dp)) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.History,
                            contentDescription = "Sem projetos salvos",
                            tint = SkyBlueAccent,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Nenhum projeto criado ainda",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Vá até a aba 'Criar App', escolha um modelo ou descreva sua ideia para salvar projetos aqui.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(
                items = uiState.historyProjects,
                key = { it.id }
            ) { project ->
                StudioCard(modifier = Modifier.widthIn(max = 720.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = project.appName,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${dateFormatter.format(Date(project.createdAtMillis))} • ${project.files.size} arquivos",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                        IconButton(
                            onClick = { onDeleteProject(project.id) },
                            modifier = Modifier.testTag("delete_project_${project.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "Excluir projeto",
                                tint = DangerRed.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = project.prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (project.capabilities.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            project.capabilities.forEach { cap ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = SkyBlueAccent.copy(alpha = 0.14f)
                                ) {
                                    Text(
                                        text = cap,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SkyBlueAccent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onInspectProject(project) },
                            border = BorderStroke(1.dp, SkyBlueAccent),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SkyBlueAccent),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Code,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Arquivos", maxLines = 1)
                        }

                        Button(
                            onClick = { onExportZip(project) },
                            enabled = !uiState.isExportingZip,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldAccent,
                                contentColor = Color(0xFF031911)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FolderZip,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Exportar .ZIP", fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
        }

        item(key = "history_footer") {
            RaylanStudioFooter()
        }
    }

    val inspectedProject = uiState.inspectedHistoryProject
    if (inspectedProject != null) {
        ProjectFilesModal(
            project = inspectedProject,
            onFileClick = onOpenFile,
            onLoadInEditor = { onLoadInEditor(inspectedProject) },
            onExportZip = { onExportZip(inspectedProject) },
            onDismiss = onDismissProjectModal
        )
    }
}

@Composable
private fun ProjectFilesModal(
    project: GeneratedProject,
    onFileClick: (GeneratedFile) -> Unit,
    onLoadInEditor: () -> Unit,
    onExportZip: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            shape = RoundedCornerShape(18.dp),
            color = SoftBlackBg,
            border = BorderStroke(1.dp, SlateBorder)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = project.appName,
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Text(
                            text = "${project.files.size} arquivos • Toque para visualizar",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                            color = TextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Fechar modal",
                            tint = TextSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onLoadInEditor,
                        border = BorderStroke(1.dp, SkyBlueAccent),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SkyBlueAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Abrir no Editor", maxLines = 1)
                    }
                    Button(
                        onClick = onExportZip,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldAccent,
                            contentColor = Color(0xFF031911)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FolderZip,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Baixar .ZIP", fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(project.files, key = { it.path }) { file ->
                        GeneratedFileRow(
                            file = file,
                            onClick = { onFileClick(file) }
                        )
                    }
                }
            }
        }
    }
}
