package com.raylan.studioai.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val RaylanDarkColorScheme = darkColorScheme(
    primary = SkyBlueAccent,
    onPrimary = Color(0xFF04131D),
    primaryContainer = Color(0xFF0C2D42),
    onPrimaryContainer = SkyBlueAccent,
    secondary = EmeraldAccent,
    onSecondary = Color(0xFF031911),
    secondaryContainer = Color(0xFF0B2E23),
    onSecondaryContainer = EmeraldAccent,
    tertiary = WarningAmber,
    background = SoftBlackBg,
    onBackground = TextPrimary,
    surface = SlateCardBg,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = SlateBorder,
    outlineVariant = SlateBorder,
    error = DangerRed,
    onError = Color.White
)

private val RaylanShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

@Composable
fun RaylanStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RaylanDarkColorScheme,
        typography = RaylanTypography,
        shapes = RaylanShapes,
        content = content
    )
}
