package com.raylan.studioai.model

enum class StudioTab(val label: String) {
    CREATE("Criar App"),
    PROJECTS("Meus Projetos"),
    SETTINGS("API & Criador")
}

data class GeneratedFile(
    val path: String,
    val content: String
) {
    val lineCount: Int
        get() = if (content.isEmpty()) 0 else content.lines().size

    val fileName: String
        get() = path.substringAfterLast('/')
}

data class GeneratedProject(
    val id: String,
    val appName: String,
    val prompt: String,
    val files: List<GeneratedFile>,
    val createdAtMillis: Long,
    val capabilities: List<String> = emptyList()
)

data class QuickPreset(
    val title: String,
    val suggestedAppName: String,
    val promptTemplate: String
)

data class ExportedZipResult(
    val fileName: String,
    val displayLocation: String,
    val sizeBytes: Long,
    val fileCount: Int
)

sealed interface ApiTestState {
    data object Idle : ApiTestState
    data object Testing : ApiTestState
    data class Success(val message: String) : ApiTestState
    data class Error(val message: String) : ApiTestState
}
