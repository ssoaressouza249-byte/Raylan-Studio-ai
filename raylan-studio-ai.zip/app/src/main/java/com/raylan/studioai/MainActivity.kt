package com.raylan.studioai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raylan.studioai.model.StudioTab
import com.raylan.studioai.security.SecurityGuard
import com.raylan.studioai.security.TamperLockScreen
import com.raylan.studioai.ui.StudioUiState
import com.raylan.studioai.ui.StudioViewModel
import com.raylan.studioai.ui.components.CodeViewerDialog
import com.raylan.studioai.ui.components.RaylanStudioHeader
import com.raylan.studioai.ui.screens.CreateAppScreen
import com.raylan.studioai.ui.screens.ProjectsHistoryScreen
import com.raylan.studioai.ui.screens.SettingsCreatorScreen
import com.raylan.studioai.ui.theme.RaylanStudioTheme
import com.raylan.studioai.ui.theme.SkyBlueAccent
import com.raylan.studioai.ui.theme.SlateBorder
import com.raylan.studioai.ui.theme.SlateCardBg
import com.raylan.studioai.ui.theme.SoftBlackBg
import com.raylan.studioai.ui.theme.TextMuted
import com.raylan.studioai.ui.theme.TextPrimary

class MainActivity : ComponentActivity() {

    private var integrityState by mutableStateOf(SecurityGuard.IntegrityResult(isIntact = true))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        integrityState = SecurityGuard.verifyIntegrity(this)

        setContent {
            RaylanStudioTheme {
                if (!integrityState.isIntact) {
                    TamperLockScreen(reason = integrityState.reason)
                } else {
                    RaylanStudioApp()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        integrityState = SecurityGuard.verifyIntegrity(this)
    }
}

@Composable
fun RaylanStudioApp(
    viewModel: StudioViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(SoftBlackBg)
    ) {
        val useNavigationRail = maxWidth >= 840.dp

        if (useNavigationRail) {
            Scaffold(
                containerColor = SoftBlackBg,
                contentWindowInsets = WindowInsets.safeDrawing
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    NavigationRail(
                        containerColor = SlateCardBg,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        StudioTab.entries.forEach { tab ->
                            val selected = uiState.selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = tabTitle(tab)
                                    )
                                },
                                label = { Text(tabTitle(tab)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = SkyBlueAccent,
                                    selectedTextColor = SkyBlueAccent,
                                    indicatorColor = SkyBlueAccent.copy(alpha = 0.14f),
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        RaylanStudioHeader(hasApiKey = uiState.savedApiKey.isNotBlank())
                        HorizontalDivider(color = SlateBorder, thickness = 1.dp)
                        Box(modifier = Modifier.weight(1f)) {
                            StudioTabContent(uiState = uiState, viewModel = viewModel)
                        }
                    }
                }
            }
        } else {
            Scaffold(
                containerColor = SoftBlackBg,
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    Column(
                        modifier = Modifier
                            .background(SoftBlackBg)
                            .statusBarsPadding()
                    ) {
                        RaylanStudioHeader(hasApiKey = uiState.savedApiKey.isNotBlank())
                        HorizontalDivider(color = SlateBorder, thickness = 1.dp)
                    }
                },
                bottomBar = {
                    Column {
                        HorizontalDivider(color = SlateBorder, thickness = 1.dp)
                        NavigationBar(
                            containerColor = SlateCardBg,
                            contentColor = TextPrimary,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            StudioTab.entries.forEach { tab ->
                                val selected = uiState.selectedTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = {
                                        Icon(
                                            imageVector = tabIcon(tab, selected),
                                            contentDescription = tabTitle(tab)
                                        )
                                    },
                                    label = { Text(tabTitle(tab)) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SkyBlueAccent,
                                        selectedTextColor = SkyBlueAccent,
                                        indicatorColor = SkyBlueAccent.copy(alpha = 0.14f),
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    StudioTabContent(uiState = uiState, viewModel = viewModel)
                }
            }
        }
    }

    uiState.selectedFileToInspect?.let { file ->
        CodeViewerDialog(
            file = file,
            onDismiss = viewModel::closeFileInspector
        )
    }
}

@Composable
private fun StudioTabContent(
    uiState: StudioUiState,
    viewModel: StudioViewModel
) {
    when (uiState.selectedTab) {
        StudioTab.CREATE -> CreateAppScreen(
            uiState = uiState,
            presets = viewModel.quickPresets,
            onAppNameChange = viewModel::updateAppName,
            onPromptChange = viewModel::updatePrompt,
            onPresetSelected = viewModel::applyPreset,
            onEnhancePrompt = viewModel::enhancePrompt,
            onGenerateApp = viewModel::generateFullApp,
            onFileClick = viewModel::openFileInspector,
            onDownloadZip = viewModel::exportProjectZip,
            onDismissStatus = viewModel::dismissStatusMessage
        )

        StudioTab.PROJECTS -> ProjectsHistoryScreen(
            uiState = uiState,
            onInspectProject = viewModel::openHistoryProject,
            onDismissProjectModal = viewModel::closeHistoryProject,
            onOpenFile = viewModel::openFileInspector,
            onExportZip = viewModel::exportProjectZip,
            onLoadInEditor = viewModel::loadHistoryProjectIntoEditor,
            onDeleteProject = viewModel::deleteHistoryProject,
            onDismissStatus = viewModel::dismissStatusMessage
        )

        StudioTab.SETTINGS -> SettingsCreatorScreen(
            uiState = uiState,
            onApiKeyDraftChange = viewModel::updateApiKeyDraft,
            onSaveApiKey = viewModel::saveApiKey,
            onTestApiKey = viewModel::testApiKey,
            onDismissStatus = viewModel::dismissStatusMessage
        )
    }
}

private fun tabIcon(tab: StudioTab, selected: Boolean): ImageVector {
    return when (tab) {
        StudioTab.CREATE -> if (selected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
        StudioTab.PROJECTS -> if (selected) Icons.Filled.FolderCopy else Icons.Outlined.FolderCopy
        StudioTab.SETTINGS -> if (selected) Icons.Filled.Settings else Icons.Outlined.Settings
    }
}

@Composable
private fun tabTitle(tab: StudioTab): String {
    return when (tab) {
        StudioTab.CREATE -> stringResource(R.string.tab_create)
        StudioTab.PROJECTS -> stringResource(R.string.tab_projects)
        StudioTab.SETTINGS -> stringResource(R.string.tab_settings)
    }
}
