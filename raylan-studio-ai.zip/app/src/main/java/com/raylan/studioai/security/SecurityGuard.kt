package com.raylan.studioai.security

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.studioai.R

object SecurityGuard {

    const val EXPECTED_PACKAGE_NAME = "com.raylan.studioai"
    const val EXPECTED_APP_NAME = "Raylan Studio AI"
    const val EXPECTED_MAIN_ACTIVITY = "com.raylan.studioai.MainActivity"

    data class IntegrityResult(
        val isIntact: Boolean,
        val reason: String? = null
    )

    /**
     * Verifica integridade de pacote, nome visível do app (strings.xml e ApplicationInfo.loadLabel)
     * e integridade da MainActivity, sem bloquear certificados de debug do GitHub Actions.
     */
    fun verifyIntegrity(activity: Activity): IntegrityResult {
        val context: Context = activity.applicationContext

        if (context.packageName != EXPECTED_PACKAGE_NAME) {
            return IntegrityResult(
                isIntact = false,
                reason = "Pacote inválido: ${context.packageName}"
            )
        }

        val stringAppName = runCatching { context.getString(R.string.app_name) }.getOrNull()
        if (stringAppName != EXPECTED_APP_NAME) {
            return IntegrityResult(
                isIntact = false,
                reason = "Nome do aplicativo alterado em strings.xml"
            )
        }

        val pm = context.packageManager
        val loadedLabel = runCatching {
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(
                    context.packageName,
                    PackageManager.ApplicationInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(context.packageName, 0)
            }
            appInfo.loadLabel(pm).toString()
        }.getOrNull()

        if (loadedLabel != EXPECTED_APP_NAME) {
            return IntegrityResult(
                isIntact = false,
                reason = "ApplicationInfo.loadLabel adulterado"
            )
        }

        if (activity::class.java.name != EXPECTED_MAIN_ACTIVITY) {
            return IntegrityResult(
                isIntact = false,
                reason = "Classe da MainActivity adulterada"
            )
        }

        val manifestMainOk = runCatching {
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(
                    context.packageName,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_ACTIVITIES.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, PackageManager.GET_ACTIVITIES)
            }
            val activities = pkgInfo.activities
            activities == null || activities.any { it.name == EXPECTED_MAIN_ACTIVITY && it.exported }
        }.getOrDefault(true)

        if (!manifestMainOk) {
            return IntegrityResult(
                isIntact = false,
                reason = "MainActivity ausente ou modificada no Manifesto"
            )
        }

        return IntegrityResult(isIntact = true)
    }

    fun launchUninstallIntent(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}

@Composable
fun TamperLockScreen(
    reason: String? = null
) {
    val context = LocalContext.current

    // Bloqueia o botão voltar de forma permanente enquanto estiver nesta tela
    BackHandler(enabled = true) {}

    // Dispara automaticamente a solicitação de desinstalação ao detectar adulteração
    LaunchedEffect(Unit) {
        SecurityGuard.launchUninstallIntent(context)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF991B1B),
                        Color(0xFF7F1D1D),
                        Color(0xFF450A0A)
                    )
                )
            )
            .safeDrawingPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.GppBad,
                contentDescription = stringResource(R.string.security_tamper_title),
                tint = Color.White,
                modifier = Modifier.size(92.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = stringResource(R.string.security_tamper_title),
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold
                ),
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = stringResource(R.string.security_tamper_message),
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 24.sp
                ),
                color = Color(0xFFFEE2E2),
                textAlign = TextAlign.Center
            )

            if (!reason.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = reason,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFFCA5A5),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { SecurityGuard.launchUninstallIntent(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("security_uninstall_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF991B1B)
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteForever,
                    contentDescription = null,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.size(10.dp))
                Text(
                    text = stringResource(R.string.security_uninstall_now),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                )
            }
        }
    }
}
