package com.raylan.studioai.ui.theme

import androidx.compose.ui.graphics.Color

val SoftBlackBg = Color(0xFF0A0C10)
val SlateCardBg = Color(0xFF12161F)
val SlateSurfaceElevated = Color(0xFF171D29)
val SlateBorder = Color(0xFF1E293B)
val SkyBlueAccent = Color(0xFF38BDF8)
val EmeraldAccent = Color(0xFF10B981)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val DangerRed = Color(0xFFDC2626)
val DangerRedDark = Color(0xFF7F1D1D)
val WarningAmber = Color(0xFFF59E0B)
