package com.raylan.studioai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.studioai.data.StudioPreferencesRepository
import com.raylan.studioai.export.ProjectZipExporter
import com.raylan.studioai.generator.GeminiAppGenerator
import com.raylan.studioai.model.ApiTestState
import com.raylan.studioai.model.ExportedZipResult
import com.raylan.studioai.model.GeneratedFile
import com.raylan.studioai.model.GeneratedProject
import com.raylan.studioai.model.QuickPreset
import com.raylan.studioai.model.StudioTab
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class StudioUiState(
    val selectedTab: StudioTab = StudioTab.CREATE,
    val appName: String = "",
    val prompt: String = "",
    val savedApiKey: String = "",
    val apiKeyDraft: String = "",
    val isEnhancingPrompt: Boolean = false,
    val isGenerating: Boolean = false,
    val generationProgress: Float = 0f,
    val generationStage: String = "",
    val remainingSeconds: Int = 55,
    val elapsedSeconds: Int = 0,
    val currentProject: GeneratedProject? = null,
    val historyProjects: List<GeneratedProject> = emptyList(),
    val selectedFileToInspect: GeneratedFile? = null,
    val inspectedHistoryProject: GeneratedProject? = null,
    val isExportingZip: Boolean = false,
    val lastExportResult: ExportedZipResult? = null,
    val apiTestState: ApiTestState = ApiTestState.Idle,
    val statusMessage: String? = null,
    val isStatusError: Boolean = false
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StudioPreferencesRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var apiKeySyncedOnce = false

    val quickPresets: List<QuickPreset> = listOf(
        QuickPreset(
            title = "App com Shizuku",
            suggestedAppName = "Shizuku Commander",
            promptTemplate = "Crie um aplicativo gerenciador de sistema usando Shizuku (dev.rikka.shizuku:api:13.1.5 + IShellService.aidl + ShizukuProvider). Inclua verificação de permissão Shizuku, terminal rápido para executar comandos ADB sem root, limpador de cache de apps e painel de status em Jetpack Compose dark."
        ),
        QuickPreset(
            title = "Mira Flutuante (Overlay)",
            suggestedAppName = "Mira Tactica Pro",
            promptTemplate = "Crie um aplicativo de Mira Flutuante usando Sobreposição de Tela (SYSTEM_ALERT_WINDOW), ForegroundService com specialUse e WindowManager com FLAG_NOT_TOUCHABLE para não bloquear toques no jogo. Permita escolher estilo de mira, cor neon, tamanho e ligar/desligar com um toque."
        ),
        QuickPreset(
            title = "Automação Acessibilidade",
            suggestedAppName = "AutoTap Studio",
            promptTemplate = "Crie um aplicativo de automação usando AccessibilityService + arquivo XML de configuração (canPerformGestures e canRetrieveWindowContent). Inclua painel para ativar o serviço nas configurações de acessibilidade, configurar sequência de toques automáticos com intervalo em ms e botão flutuante iniciar/pausar."
        ),
        QuickPreset(
            title = "Painel Gamer Pro",
            suggestedAppName = "Gamer HUD Booster",
            promptTemplate = "Crie um Painel Gamer Pro com monitoramento de bateria/temperatura/FPS em tempo real, modo desempenho, atalhos rápidos de jogos, HUD flutuante opcional (SYSTEM_ALERT_WINDOW) e suporte a comandos de otimização via Shizuku em Material 3 escuro."
        )
    )

    init {
        viewModelScope.launch {
            repository.apiKeyFlow.collect { key ->
                _uiState.update { state ->
                    state.copy(
                        savedApiKey = key,
                        apiKeyDraft = if (!apiKeySyncedOnce) key else state.apiKeyDraft
                    )
                }
                apiKeySyncedOnce = true
            }
        }

        viewModelScope.launch {
            repository.projectsFlow.collect { projects ->
                _uiState.update { it.copy(historyProjects = projects) }
            }
        }
    }

    fun selectTab(tab: StudioTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun updateAppName(value: String) {
        _uiState.update { it.copy(appName = value) }
    }

    fun updatePrompt(value: String) {
        _uiState.update { it.copy(prompt = value) }
    }

    fun applyPreset(preset: QuickPreset) {
        _uiState.update { state ->
            state.copy(
                appName = if (state.appName.isBlank()) preset.suggestedAppName else state.appName,
                prompt = preset.promptTemplate,
                statusMessage = "Modelo '${preset.title}' carregado.",
                isStatusError = false
            )
        }
    }

    fun updateApiKeyDraft(value: String) {
        _uiState.update {
            it.copy(
                apiKeyDraft = value,
                apiTestState = ApiTestState.Idle
            )
        }
    }

    fun saveApiKey() {
        val draft = _uiState.value.apiKeyDraft.trim()
        viewModelScope.launch {
            repository.saveApiKey(draft)
                .onSuccess {
                    _uiState.update {
                        it.copy(
                            savedApiKey = draft,
                            apiKeyDraft = draft,
                            statusMessage = if (draft.isEmpty()) {
                                "Chave API removida."
                            } else {
                                "Chave API salva localmente com segurança!"
                            },
                            isStatusError = false
                        )
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            statusMessage = "Erro ao salvar chave: ${err.message}",
                            isStatusError = true
                        )
                    }
                }
        }
    }

    fun testApiKey() {
        val keyToTest = _uiState.value.apiKeyDraft.trim().ifBlank { _uiState.value.savedApiKey }
        viewModelScope.launch {
            _uiState.update { it.copy(apiTestState = ApiTestState.Testing) }
            if (keyToTest.isNotBlank() && keyToTest != _uiState.value.savedApiKey) {
                repository.saveApiKey(keyToTest)
            }
            GeminiAppGenerator.testApiKey(keyToTest)
                .onSuccess { msg ->
                    _uiState.update {
                        it.copy(
                            savedApiKey = keyToTest,
                            apiTestState = ApiTestState.Success(msg)
                        )
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            apiTestState = ApiTestState.Error(
                                err.message ?: "Não foi possível validar a chave API."
                            )
                        )
                    }
                }
        }
    }

    fun enhancePrompt() {
        val state = _uiState.value
        val key = state.savedApiKey.ifBlank { state.apiKeyDraft.trim() }
        if (key.isBlank()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Cole e salve sua Chave API do Google AI Studio na aba 'API & Criador'.",
                    isStatusError = true,
                    selectedTab = StudioTab.SETTINGS
                )
            }
            return
        }
        if (state.prompt.isBlank()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Escreva uma ideia inicial no campo de prompt antes de melhorar.",
                    isStatusError = true
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isEnhancingPrompt = true,
                    statusMessage = null,
                    isStatusError = false
                )
            }
            GeminiAppGenerator.enhancePrompt(
                apiKey = key,
                appName = state.appName,
                roughPrompt = state.prompt
            ).onSuccess { improved ->
                _uiState.update {
                    it.copy(
                        isEnhancingPrompt = false,
                        prompt = improved,
                        statusMessage = "Prompt aprimorado com especificações técnicas Android!",
                        isStatusError = false
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isEnhancingPrompt = false,
                        statusMessage = err.message ?: "Erro ao melhorar prompt.",
                        isStatusError = true
                    )
                }
            }
        }
    }

    fun generateFullApp() {
        val state = _uiState.value
        val key = state.savedApiKey.ifBlank { state.apiKeyDraft.trim() }
        if (key.isBlank()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Configure sua Chave API na aba 'API & Criador' para gerar apps.",
                    isStatusError = true,
                    selectedTab = StudioTab.SETTINGS
                )
            }
            return
        }
        if (state.prompt.isBlank()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Descreva o aplicativo que deseja criar no campo de prompt.",
                    isStatusError = true
                )
            }
            return
        }

        val resolvedAppName = state.appName.trim().ifBlank { "MeuAppRaylan" }
        val stages = buildDynamicStages(state.prompt)
        val estimatedTotal = 55

        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var elapsed = 0
            while (isActive) {
                val remaining = (estimatedTotal - elapsed).coerceAtLeast(0)
                val progress = if (elapsed < estimatedTotal) {
                    0.08f + (elapsed.toFloat() / estimatedTotal.toFloat()) * 0.84f
                } else {
                    0.94f
                }
                val stageIndex = ((elapsed / 10).coerceAtMost(stages.lastIndex))
                _uiState.update {
                    it.copy(
                        elapsedSeconds = elapsed,
                        remainingSeconds = remaining,
                        generationProgress = progress,
                        generationStage = stages[stageIndex]
                    )
                }
                delay(1000L)
                elapsed++
            }
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGenerating = true,
                    appName = resolvedAppName,
                    generationProgress = 0.08f,
                    remainingSeconds = estimatedTotal,
                    elapsedSeconds = 0,
                    generationStage = stages.first(),
                    lastExportResult = null,
                    statusMessage = null,
                    isStatusError = false
                )
            }

            GeminiAppGenerator.generateFullProject(
                apiKey = key,
                appName = resolvedAppName,
                prompt = state.prompt
            ).onSuccess { project ->
                timerJob?.cancel()
                repository.saveProject(project)
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        generationProgress = 1f,
                        remainingSeconds = 0,
                        currentProject = project,
                        statusMessage = "Projeto '${project.appName}' gerado com ${project.files.size} arquivos!",
                        isStatusError = false
                    )
                }
            }.onFailure { err ->
                timerJob?.cancel()
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        generationProgress = 0f,
                        statusMessage = err.message ?: "Falha na geração do aplicativo.",
                        isStatusError = true
                    )
                }
            }
        }
    }

    private fun buildDynamicStages(prompt: String): List<String> {
        val lower = prompt.lowercase()
        val firstSpecialStage = when {
            "shizuku" in lower -> "Estruturando Manifesto e Shizuku..."
            "overlay" in lower || "sobreposi" in lower || "mira" in lower ->
                "Configurando Overlay e WindowManager..."
            "acessibilidade" in lower || "accessibility" in lower ->
                "Estruturando AccessibilityService e XML..."
            else -> "Estruturando Manifesto e Gradle..."
        }
        return listOf(
            "Analisando arquitetura Android...",
            firstSpecialStage,
            "Escrevendo telas Compose e ViewModel...",
            "Configurando recursos e permissões...",
            "Montando workflow GitHub Actions..."
        )
    }

    fun openFileInspector(file: GeneratedFile) {
        _uiState.update { it.copy(selectedFileToInspect = file) }
    }

    fun closeFileInspector() {
        _uiState.update { it.copy(selectedFileToInspect = null) }
    }

    fun openHistoryProject(project: GeneratedProject) {
        _uiState.update { it.copy(inspectedHistoryProject = project) }
    }

    fun closeHistoryProject() {
        _uiState.update { it.copy(inspectedHistoryProject = null) }
    }

    fun loadHistoryProjectIntoEditor(project: GeneratedProject) {
        _uiState.update {
            it.copy(
                selectedTab = StudioTab.CREATE,
                appName = project.appName,
                prompt = project.prompt,
                currentProject = project,
                inspectedHistoryProject = null,
                statusMessage = "Projeto '${project.appName}' carregado.",
                isStatusError = false
            )
        }
    }

    fun deleteHistoryProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            _uiState.update { state ->
                val updatedHistorySelection = if (state.inspectedHistoryProject?.id == projectId) {
                    null
                } else {
                    state.inspectedHistoryProject
                }
                state.copy(
                    inspectedHistoryProject = updatedHistorySelection,
                    statusMessage = "Projeto removido do histórico.",
                    isStatusError = false
                )
            }
        }
    }

    fun exportProjectZip(project: GeneratedProject) {
        viewModelScope.launch {
            _uiState.update { it.copy(isExportingZip = true, statusMessage = null) }
            ProjectZipExporter.exportProjectToDownloads(
                context = getApplication(),
                project = project
            ).onSuccess { result ->
                _uiState.update {
                    it.copy(
                        isExportingZip = false,
                        lastExportResult = result,
                        statusMessage = "ZIP salvo em ${result.displayLocation} (${result.fileCount} arquivos).",
                        isStatusError = false
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isExportingZip = false,
                        statusMessage = "Erro ao exportar ZIP: ${err.message}",
                        isStatusError = true
                    )
                }
            }
        }
    }

    fun dismissStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    override fun onCleared() {
        timerJob?.cancel()
        super.onCleared()
    }
}
