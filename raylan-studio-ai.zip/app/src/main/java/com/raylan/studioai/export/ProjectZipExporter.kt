package com.raylan.studioai.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.raylan.studioai.generator.GeminiAppGenerator
import com.raylan.studioai.model.ExportedZipResult
import com.raylan.studioai.model.GeneratedFile
import com.raylan.studioai.model.GeneratedProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ProjectZipExporter {

    suspend fun exportProjectToDownloads(
        context: Context,
        project: GeneratedProject
    ): Result<ExportedZipResult> = withContext(Dispatchers.IO) {
        exportFilesToDownloads(
            context = context,
            appName = project.appName,
            files = project.files
        )
    }

    suspend fun exportRawOutputToDownloads(
        context: Context,
        appName: String,
        rawOutput: String
    ): Result<ExportedZipResult> = withContext(Dispatchers.IO) {
        runCatching {
            val files = GeminiAppGenerator.parseGeneratedFiles(rawOutput)
            require(files.isNotEmpty()) { "Nenhum arquivo válido encontrado para compactar." }
            exportFilesToDownloads(context, appName, files).getOrThrow()
        }
    }

    suspend fun exportFilesToDownloads(
        context: Context,
        appName: String,
        files: List<GeneratedFile>
    ): Result<ExportedZipResult> = withContext(Dispatchers.IO) {
        runCatching {
            require(files.isNotEmpty()) { "O projeto não possui arquivos para exportar." }

            val zipBytes = buildZipBytes(files)
            val fileName = "${slugifyAppName(appName)}.zip"

            val location = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveWithMediaStore(context, fileName, zipBytes)
            } else {
                saveLegacyDownloads(fileName, zipBytes)
            }

            ExportedZipResult(
                fileName = fileName,
                displayLocation = location,
                sizeBytes = zipBytes.size.toLong(),
                fileCount = files.size
            )
        }
    }

    fun buildZipBytes(files: List<GeneratedFile>): ByteArray {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            val addedEntries = HashSet<String>()
            files.forEach { file ->
                val safePath = file.path
                    .replace('\\', '/')
                    .trimStart('/')
                    .split('/')
                    .filter { it.isNotBlank() && it != "." && it != ".." }
                    .joinToString("/")

                if (safePath.isNotBlank() && addedEntries.add(safePath)) {
                    val entry = ZipEntry(safePath)
                    zos.putNextEntry(entry)
                    zos.write(file.content.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            }
        }
        return baos.toByteArray()
    }

    private fun saveWithMediaStore(
        context: Context,
        fileName: String,
        zipBytes: ByteArray
    ): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
        }

        val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val itemUri = resolver.insert(collectionUri, values)
            ?: error("Não foi possível criar o arquivo na pasta Downloads.")

        runCatching {
            resolver.openOutputStream(itemUri)?.use { outputStream ->
                outputStream.write(zipBytes)
                outputStream.flush()
            } ?: error("Falha ao abrir fluxo de gravação no Downloads.")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val updateValues = ContentValues().apply {
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                resolver.update(itemUri, updateValues, null, null)
            }
        }.onFailure { error ->
            runCatching { resolver.delete(itemUri, null, null) }
            throw error
        }

        return "Downloads/$fileName"
    }

    @Suppress("DEPRECATION")
    private fun saveLegacyDownloads(
        fileName: String,
        zipBytes: ByteArray
    ): String {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS
        )
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs()
        }
        var targetFile = File(downloadsDir, fileName)
        if (targetFile.exists()) {
            val baseName = fileName.removeSuffix(".zip")
            targetFile = File(downloadsDir, "${baseName}_${System.currentTimeMillis()}.zip")
        }
        FileOutputStream(targetFile).use { fos ->
            fos.write(zipBytes)
            fos.flush()
        }
        return targetFile.absolutePath
    }

    fun slugifyAppName(appName: String): String {
        val normalized = appName.trim()
            .lowercase()
            .replace(Regex("[áàâãä]"), "a")
            .replace(Regex("[éèêë]"), "e")
            .replace(Regex("[íìîï]"), "i")
            .replace(Regex("[óòôõö]"), "o")
            .replace(Regex("[úùûü]"), "u")
            .replace("ç", "c")
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
        return normalized.ifBlank { "raylan-android-app" }
    }
}
