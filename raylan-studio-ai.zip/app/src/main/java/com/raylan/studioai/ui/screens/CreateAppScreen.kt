package com.raylan.studioai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.studioai.model.GeneratedFile
import com.raylan.studioai.model.GeneratedProject
import com.raylan.studioai.model.QuickPreset
import com.raylan.studioai.ui.StudioUiState
import com.raylan.studioai.ui.components.GeneratedFileRow
import com.raylan.studioai.ui.components.GenerationProgressCard
import com.raylan.studioai.ui.components.RaylanStudioFooter
import com.raylan.studioai.ui.components.StatusBanner
import com.raylan.studioai.ui.components.StudioCard
import com.raylan.studioai.ui.theme.EmeraldAccent
import com.raylan.studioai.ui.theme.SkyBlueAccent
import com.raylan.studioai.ui.theme.SlateBorder
import com.raylan.studioai.ui.theme.SlateSurfaceElevated
import com.raylan.studioai.ui.theme.SoftBlackBg
import com.raylan.studioai.ui.theme.TextMuted
import com.raylan.studioai.ui.theme.TextPrimary
import com.raylan.studioai.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateAppScreen(
    uiState: StudioUiState,
    presets: List<QuickPreset>,
    onAppNameChange: (String) -> Unit,
    onPromptChange: (String) -> Unit,
    onPresetSelected: (QuickPreset) -> Unit,
    onEnhancePrompt: () -> Unit,
    onGenerateApp: () -> Unit,
    onFileClick: (GeneratedFile) -> Unit,
    onDownloadZip: (GeneratedProject) -> Unit,
    onDismissStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = SoftBlackBg,
        unfocusedContainerColor = SoftBlackBg,
        focusedBorderColor = SkyBlueAccent,
        unfocusedBorderColor = SlateBorder,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = SkyBlueAccent,
        unfocusedLabelColor = TextSecondary,
        cursorColor = SkyBlueAccent
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (!uiState.statusMessage.isNullOrBlank()) {
            item(key = "status_banner") {
                StatusBanner(
                    message = uiState.statusMessage,
                    isError = uiState.isStatusError,
                    onDismiss = onDismissStatus,
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        }

        item(key = "builder_form") {
            StudioCard(modifier = Modifier.widthIn(max = 720.dp)) {
                Text(
                    text = "Estúdio de Criação por Prompt",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Descreva seu aplicativo e gere o código Android nativo completo pronto para o GitHub Actions.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = uiState.appName,
                    onValueChange = onAppNameChange,
                    label = { Text("Nome do App") },
                    placeholder = { Text("Ex: Mira Flutuante Pro", color = TextMuted) },
                    singleLine = true,
                    enabled = !uiState.isGenerating,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_name_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = uiState.prompt,
                    onValueChange = onPromptChange,
                    label = { Text("Prompt do Aplicativo") },
                    placeholder = {
                        Text(
                            "Ex: Crie um app com Shizuku ou Overlay de tela em Jetpack Compose...",
                            color = TextMuted
                        )
                    },
                    enabled = !uiState.isGenerating && !uiState.isEnhancingPrompt,
                    colors = fieldColors,
                    shape = RoundedCornerShape(12.dp),
                    minLines = 5,
                    maxLines = 9,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 148.dp)
                        .testTag("app_prompt_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Modelos Rápidos (1 toque)",
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presets.forEach { preset ->
                        FilterChip(
                            selected = uiState.prompt == preset.promptTemplate,
                            onClick = { onPresetSelected(preset) },
                            enabled = !uiState.isGenerating,
                            label = {
                                Text(
                                    text = preset.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp)
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Bolt,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = SlateSurfaceElevated,
                                labelColor = TextPrimary,
                                iconColor = SkyBlueAccent,
                                selectedContainerColor = SkyBlueAccent.copy(alpha = 0.18f),
                                selectedLabelColor = SkyBlueAccent,
                                selectedLeadingIconColor = SkyBlueAccent
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = !uiState.isGenerating,
                                selected = uiState.prompt == preset.promptTemplate,
                                borderColor = SlateBorder,
                                selectedBorderColor = SkyBlueAccent
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onEnhancePrompt,
                        enabled = !uiState.isGenerating && !uiState.isEnhancingPrompt,
                        border = BorderStroke(1.2.dp, SkyBlueAccent),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SkyBlueAccent),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("enhance_prompt_button")
                    ) {
                        if (uiState.isEnhancingPrompt) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = SkyBlueAccent
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.AutoFixHigh,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (uiState.isEnhancingPrompt) "Melhorando..." else "Melhorar Prompt",
                            maxLines = 1
                        )
                    }

                    Button(
                        onClick = onGenerateApp,
                        enabled = !uiState.isGenerating && !uiState.isEnhancingPrompt,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldAccent,
                            contentColor = Color(0xFF031911),
                            disabledContainerColor = EmeraldAccent.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("generate_app_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RocketLaunch,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Gerar App Completo",
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        item(key = "progress_card") {
            AnimatedVisibility(visible = uiState.isGenerating) {
                GenerationProgressCard(
                    progress = uiState.generationProgress,
                    stage = uiState.generationStage,
                    remainingSeconds = uiState.remainingSeconds,
                    elapsedSeconds = uiState.elapsedSeconds,
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        }

        val generatedProject = uiState.currentProject
        if (generatedProject != null && !uiState.isGenerating) {
            item(key = "project_summary_export") {
                StudioCard(
                    modifier = Modifier.widthIn(max = 720.dp),
                    borderColor = EmeraldAccent.copy(alpha = 0.55f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Projeto gerado",
                                tint = EmeraldAccent,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = generatedProject.appName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${generatedProject.files.size} arquivos gerados • Clique para ler o código",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    if (generatedProject.capabilities.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            generatedProject.capabilities.forEach { cap ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = SkyBlueAccent.copy(alpha = 0.14f),
                                    border = BorderStroke(1.dp, SkyBlueAccent.copy(alpha = 0.35f))
                                ) {
                                    Text(
                                        text = cap,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SkyBlueAccent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onDownloadZip(generatedProject) },
                        enabled = !uiState.isExportingZip,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldAccent,
                            contentColor = Color(0xFF031911)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("download_zip_button")
                    ) {
                        if (uiState.isExportingZip) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF031911)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.FolderZip,
                                contentDescription = null,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BAIXAR PROJETO .ZIP (PRONTO P/ GITHUB)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    uiState.lastExportResult?.let { exportInfo ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Archive,
                                contentDescription = null,
                                tint = EmeraldAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Salvo em: ${exportInfo.displayLocation}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldAccent
                            )
                        }
                    }
                }
            }

            items(
                items = generatedProject.files,
                key = { file -> "${generatedProject.id}_${file.path}" }
            ) { file ->
                GeneratedFileRow(
                    file = file,
                    onClick = { onFileClick(file) },
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        }

        item(key = "footer") {
            RaylanStudioFooter()
        }
    }
}
