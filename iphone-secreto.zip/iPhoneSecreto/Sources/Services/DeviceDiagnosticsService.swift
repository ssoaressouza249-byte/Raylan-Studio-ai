import Foundation
import SwiftUI
import UIKit
import Darwin

enum ThermalStatusLevel {
    case nominal
    case fair
    case serious
    case critical

    var title: String {
        switch self {
        case .nominal: return "Nominal (Frio)"
        case .fair: return "Moderado (Aquecimento Leve)"
        case .serious: return "Elevado (Throttling Próximo)"
        case .critical: return "Crítico (Superaquecimento)"
        }
    }

    var badgeColor: Color {
        switch self {
        case .nominal: return CyberTheme.neonGreen
        case .fair: return CyberTheme.iosBlue
        case .serious: return CyberTheme.warningOrange
        case .critical: return CyberTheme.dangerRed
        }
    }
}

struct HiddenSettingChecklistItem: Identifiable {
    let id: String
    let title: String
    let pathDescription: String
    let detail: String
    var isCompleted: Bool
    var systemDetectedEnabled: Bool?
}

@MainActor
final class DeviceDiagnosticsService: ObservableObject {
    @Published var thermalState: ThermalStatusLevel = .nominal
    @Published var batteryPercent: Int? = nil
    @Published var batteryStateLabel: String = "Desconhecido"
    @Published var isLowPowerModeEnabled: Bool = false

    @Published var freeDiskBytes: Int64 = 0
    @Published var totalDiskBytes: Int64 = 0

    @Published var usedMemoryBytes: UInt64 = 0
    @Published var totalMemoryBytes: UInt64 = ProcessInfo.processInfo.physicalMemory
    @Published var appFootprintBytes: UInt64 = 0

    @Published var deviceModelName: String = UIDevice.current.model
    @Published var systemVersionString: String = "iOS \(UIDevice.current.systemVersion)"

    @Published var isOptimizing: Bool = false
    @Published var optimizationProgress: Double = 0.0
    @Published var optimizationStatusText: String = "Pronto para análise e otimização"
    @Published var lastOptimizationSummary: String? = nil

    @Published var checklistItems: [HiddenSettingChecklistItem] = []

    private var observers: [NSObjectProtocol] = []

    init() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        setupChecklist()
        refreshAll()
        registerNotifications()
    }

    deinit {
        for observer in observers {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    var formattedFreeDisk: String {
        ByteCountFormatter.string(fromByteCount: freeDiskBytes, countStyle: .file)
    }

    var formattedTotalDisk: String {
        ByteCountFormatter.string(fromByteCount: totalDiskBytes, countStyle: .file)
    }

    var diskUsedFraction: Double {
        guard totalDiskBytes > 0 else { return 0 }
        let used = max(0, totalDiskBytes - freeDiskBytes)
        return min(1.0, max(0.0, Double(used) / Double(totalDiskBytes)))
    }

    var formattedUsedMemory: String {
        ByteCountFormatter.string(fromByteCount: Int64(usedMemoryBytes), countStyle: .memory)
    }

    var formattedTotalMemory: String {
        ByteCountFormatter.string(fromByteCount: Int64(totalMemoryBytes), countStyle: .memory)
    }

    var formattedAppFootprint: String {
        ByteCountFormatter.string(fromByteCount: Int64(appFootprintBytes), countStyle: .memory)
    }

    var memoryUsedFraction: Double {
        guard totalMemoryBytes > 0 else { return 0 }
        return min(1.0, max(0.0, Double(usedMemoryBytes) / Double(totalMemoryBytes)))
    }

    func refreshAll() {
        readThermalState()
        readBatteryAndPower()
        readDiskSpace()
        readMemoryStats()
        syncSystemChecklistStates()
    }

    func toggleChecklistItem(_ id: String) {
        guard let index = checklistItems.firstIndex(where: { $0.id == id }) else { return }
        checklistItems[index].isCompleted.toggle()
        let generator = UIImpactFeedbackGenerator(style: .light)
        generator.impactOccurred()
    }

    func openSystemSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }

    func runFullOptimization() {
        guard !isOptimizing else { return }

        isOptimizing = true
        optimizationProgress = 0.0
        optimizationStatusText = "Iniciando varredura de cache e buffers..."

        let impact = UIImpactFeedbackGenerator(style: .medium)
        impact.prepare()
        impact.impactOccurred()

        Task { @MainActor in
            let urlCacheBefore = Int64(URLCache.shared.currentMemoryUsage + URLCache.shared.currentDiskUsage)
            await advanceProgress(to: 0.28, label: "Limpando URLCache e respostas em memória...")

            URLCache.shared.removeAllCachedResponses()

            await advanceProgress(to: 0.56, label: "Removendo arquivos temporários do sandbox...")
            let tempFreedBytes = purgeTemporaryDirectory()

            await advanceProgress(to: 0.82, label: "Liberando buffers temporários e alocação...")
            autoreleasepool {
                var scratch = Data(count: 1024 * 256)
                scratch.removeAll(keepingCapacity: false)
            }
            URLSession.shared.flush { }

            await advanceProgress(to: 1.0, label: "Atualizando telemetria real do iOS...")
            refreshAll()

            let totalFreed = urlCacheBefore + tempFreedBytes
            let formattedFreed = ByteCountFormatter.string(fromByteCount: max(totalFreed, 0), countStyle: .file)
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm:ss"

            lastOptimizationSummary = "Otimização concluída às \(formatter.string(from: Date())) • Cache/Buffers liberados: \(formattedFreed)"
            optimizationStatusText = "iPhone otimizado! Siga o checklist oculto abaixo para ganho máximo."
            isOptimizing = false

            let successFeedback = UINotificationFeedbackGenerator()
            successFeedback.notificationOccurred(.success)
        }
    }

    private func advanceProgress(to target: Double, label: String) async {
        optimizationStatusText = label
        let steps = 8
        let start = optimizationProgress
        let delta = (target - start) / Double(steps)
        for _ in 0..<steps {
            try? await Task.sleep(nanoseconds: 45_000_000)
            optimizationProgress = min(1.0, optimizationProgress + delta)
        }
        optimizationProgress = target
    }

    private func purgeTemporaryDirectory() -> Int64 {
        let fm = FileManager.default
        let tempDir = fm.temporaryDirectory
        var bytesFreed: Int64 = 0

        guard let contents = try? fm.contentsOfDirectory(
            at: tempDir,
            includingPropertiesForKeys: [.fileSizeKey],
            options: [.skipsHiddenFiles]
        ) else {
            return 0
        }

        for fileURL in contents {
            // Preserva perfis .mobileconfig gerados pelo usuário na aba 2
            if fileURL.pathExtension.lowercased() == "mobileconfig" {
                continue
            }
            if let values = try? fileURL.resourceValues(forKeys: [.fileSizeKey]),
               let fileSize = values.fileSize {
                bytesFreed += Int64(fileSize)
            }
            try? fm.removeItem(at: fileURL)
        }

        return bytesFreed
    }

    private func readThermalState() {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal:
            thermalState = .nominal
        case .fair:
            thermalState = .fair
        case .serious:
            thermalState = .serious
        case .critical:
            thermalState = .critical
        @unknown default:
            thermalState = .nominal
        }
    }

    private func readBatteryAndPower() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        let level = UIDevice.current.batteryLevel
        if level < 0 {
            batteryPercent = nil
        } else {
            batteryPercent = Int((level * 100.0).rounded())
        }

        switch UIDevice.current.batteryState {
        case .charging:
            batteryStateLabel = "Carregando"
        case .full:
            batteryStateLabel = "Carga Completa"
        case .unplugged:
            batteryStateLabel = "Na Bateria"
        case .unknown:
            batteryStateLabel = "Monitoramento Ativo"
        @unknown default:
            batteryStateLabel = "Monitoramento Ativo"
        }

        isLowPowerModeEnabled = ProcessInfo.processInfo.isLowPowerModeEnabled
    }

    private func readDiskSpace() {
        let homeURL = URL(fileURLWithPath: NSHomeDirectory())
        if let values = try? homeURL.resourceValues(forKeys: [
            .volumeAvailableCapacityForImportantUsageKey,
            .volumeTotalCapacityKey
        ]) {
            if let available = values.volumeAvailableCapacityForImportantUsage {
                freeDiskBytes = available
            }
            if let total = values.volumeTotalCapacity {
                totalDiskBytes = Int64(total)
            }
        }

        if freeDiskBytes == 0 || totalDiskBytes == 0 {
            if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()) {
                freeDiskBytes = (attrs[.systemFreeSize] as? NSNumber)?.int64Value ?? freeDiskBytes
                totalDiskBytes = (attrs[.systemSize] as? NSNumber)?.int64Value ?? totalDiskBytes
            }
        }
    }

    private func readMemoryStats() {
        totalMemoryBytes = ProcessInfo.processInfo.physicalMemory
        let pageSize = UInt64(max(1, sysconf(_SC_PAGESIZE)))

        var vmStats = vm_statistics64()
        var hostCount = mach_msg_type_number_t(
            MemoryLayout<vm_statistics64_data_t>.stride / MemoryLayout<integer_t>.stride
        )
        let hostResult = withUnsafeMutablePointer(to: &vmStats) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(hostCount)) {
                host_statistics64(mach_host_self(), HOST_VM_INFO64, $0, &hostCount)
            }
        }

        if hostResult == KERN_SUCCESS {
            let active = UInt64(vmStats.active_count) * pageSize
            let wired = UInt64(vmStats.wire_count) * pageSize
            let compressed = UInt64(vmStats.compressor_page_count) * pageSize
            usedMemoryBytes = min(totalMemoryBytes, active + wired + compressed)
        }

        var taskInfo = task_vm_info_data_t()
        var taskCount = mach_msg_type_number_t(
            MemoryLayout<task_vm_info_data_t>.stride / MemoryLayout<natural_t>.stride
        )
        let taskResult = withUnsafeMutablePointer(to: &taskInfo) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(taskCount)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &taskCount)
            }
        }

        if taskResult == KERN_SUCCESS {
            appFootprintBytes = taskInfo.phys_footprint
        }
    }

    private func setupChecklist() {
        checklistItems = [
            HiddenSettingChecklistItem(
                id: "reduce_motion",
                title: "Reduzir Movimento (Zero Animações Pesadas)",
                pathDescription: "Ajustes > Acessibilidade > Movimento > Reduzir Movimento",
                detail: "Elimina transições paralaxe da GPU para reduzir micro-engasgos.",
                isCompleted: UIAccessibility.isReduceMotionEnabled,
                systemDetectedEnabled: UIAccessibility.isReduceMotionEnabled
            ),
            HiddenSettingChecklistItem(
                id: "background_refresh",
                title: "Atualização em 2º Plano Desativada",
                pathDescription: "Ajustes > Geral > Atualização em 2º Plano > Desativado",
                detail: "Impede que outros apps consumam CPU, rede e RAM durante partidas.",
                isCompleted: UIApplication.shared.backgroundRefreshStatus != .available,
                systemDetectedEnabled: UIApplication.shared.backgroundRefreshStatus != .available
            ),
            HiddenSettingChecklistItem(
                id: "assistivetouch_ram",
                title: "Limpeza Profunda de RAM via AssistiveTouch",
                pathDescription: "Ajustes > Acessibilidade > Toque > AssistiveTouch",
                detail: "Vá em Ajustes > Geral > Desligar, abra o AssistiveTouch e segure o botão 'Início' até a tela piscar para forçar flush de RAM do kernel.",
                isCompleted: false,
                systemDetectedEnabled: nil
            )
        ]
    }

    private func syncSystemChecklistStates() {
        if let idx = checklistItems.firstIndex(where: { $0.id == "reduce_motion" }) {
            let enabled = UIAccessibility.isReduceMotionEnabled
            checklistItems[idx].systemDetectedEnabled = enabled
            if enabled {
                checklistItems[idx].isCompleted = true
            }
        }
        if let idx = checklistItems.firstIndex(where: { $0.id == "background_refresh" }) {
            let disabled = UIApplication.shared.backgroundRefreshStatus != .available
            checklistItems[idx].systemDetectedEnabled = disabled
            if disabled {
                checklistItems[idx].isCompleted = true
            }
        }
    }

    private func registerNotifications() {
        let nc = NotificationCenter.default
        let names: [Notification.Name] = [
            ProcessInfo.thermalStateDidChangeNotification,
            UIDevice.batteryLevelDidChangeNotification,
            UIDevice.batteryStateDidChangeNotification,
            Notification.Name.NSProcessInfoPowerStateDidChange,
            UIAccessibility.reduceMotionStatusDidChangeNotification,
            UIApplication.backgroundRefreshStatusDidChangeNotification
        ]

        for name in names {
            let token = nc.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                Task { @MainActor [weak self] in
                    self?.refreshAll()
                }
            }
            observers.append(token)
        }
    }
}
