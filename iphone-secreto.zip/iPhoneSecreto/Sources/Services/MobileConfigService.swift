import Foundation
import Network
import SwiftUI
import UIKit
import WebKit

enum DNSProfilePreset: String, CaseIterable, Identifiable {
    case cloudflareGamer
    case googleDNS

    var id: String { rawValue }

    var title: String {
        switch self {
        case .cloudflareGamer: return "Cloudflare Gamer"
        case .googleDNS: return "Google DNS"
        }
    }

    var primaryIP: String {
        switch self {
        case .cloudflareGamer: return "1.1.1.1"
        case .googleDNS: return "8.8.8.8"
        }
    }

    var secondaryIP: String {
        switch self {
        case .cloudflareGamer: return "1.0.0.1"
        case .googleDNS: return "8.8.4.4"
        }
    }

    var dohURL: String {
        switch self {
        case .cloudflareGamer: return "https://cloudflare-dns.com/dns-query"
        case .googleDNS: return "https://dns.google/dns-query"
        }
    }

    var subtitle: String {
        switch self {
        case .cloudflareGamer: return "1.1.1.1 / 1.0.0.1 • DoH Baixa Latência"
        case .googleDNS: return "8.8.8.8 / 8.8.4.4 • DoH Estabilidade Global"
        }
    }
}

struct ConsoleLogEntry: Identifiable {
    let id = UUID()
    let timestamp: String
    let message: String
    let isSuccess: Bool
}

@MainActor
final class MobileConfigService: ObservableObject {
    @Published var selectedDNS: DNSProfilePreset = .cloudflareGamer
    @Published var consoleLogs: [ConsoleLogEntry] = []
    @Published var generatedXML: String = ""
    @Published var generatedFileURL: URL? = nil
    @Published var localProfileURL: URL? = nil
    @Published var localPortalURL: URL? = nil
    @Published var isInjecting: Bool = false
    @Published var showShareSheet: Bool = false
    @Published var showWebPortalSheet: Bool = false

    private var listener: NWListener?
    private var activePort: UInt16 = 0
    private var latestPayloadData: Data = Data()

    init() {
        appendLog("Console Zero Delay inicializado. Pronto para injeção .mobileconfig.", isSuccess: false)
    }

    deinit {
        listener?.cancel()
    }

    func generateProfileXML(for preset: DNSProfilePreset) -> String {
        let rootUUID = UUID().uuidString
        let dnsPayloadUUID = UUID().uuidString

        return """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>PayloadContent</key>
    <array>
        <dict>
            <key>DNSSettings</key>
            <dict>
                <key>DNSProtocol</key>
                <string>HTTPS</string>
                <key>ServerAddresses</key>
                <array>
                    <string>\(preset.primaryIP)</string>
                    <string>\(preset.secondaryIP)</string>
                </array>
                <key>ServerURL</key>
                <string>\(preset.dohURL)</string>
            </dict>
            <key>PayloadDescription</key>
            <string>Configura DNS criptografado Zero Delay (\(preset.title)) para redução de jitter e ping.</string>
            <key>PayloadDisplayName</key>
            <string>DNS Gamer — \(preset.title)</string>
            <key>PayloadIdentifier</key>
            <string>com.raylan.iphonesecreto.dns.\(preset.id).settings</string>
            <key>PayloadOrganization</key>
            <string>iPhone Secreto — Raylan</string>
            <key>PayloadType</key>
            <string>com.apple.dnsSettings.managed</string>
            <key>PayloadUUID</key>
            <string>\(dnsPayloadUUID)</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
        </dict>
    </array>
    <key>PayloadDescription</key>
    <string>Perfil de otimização de rede Zero Delay gerado por iPhone Secreto (Raylan).</string>
    <key>PayloadDisplayName</key>
    <string>iPhone Secreto — \(preset.title) Zero Delay</string>
    <key>PayloadIdentifier</key>
    <string>com.raylan.iphonesecreto.profile.\(preset.id)</string>
    <key>PayloadOrganization</key>
    <string>iPhone Secreto — Criado por Raylan</string>
    <key>PayloadRemovalDisallowed</key>
    <false/>
    <key>PayloadType</key>
    <string>Configuration</string>
    <key>PayloadUUID</key>
    <string>\(rootUUID)</string>
    <key>PayloadVersion</key>
    <integer>1</integer>
</dict>
</plist>
"""
    }

    func injectProfile(openViaShareSheetAfter: Bool = false) {
        guard !isInjecting else { return }
        isInjecting = true
        consoleLogs.removeAll()

        let impact = UIImpactFeedbackGenerator(style: .heavy)
        impact.impactOccurred()

        let preset = selectedDNS
        let xml = generateProfileXML(for: preset)
        generatedXML = xml

        Task { @MainActor in
            appendLog("[INIT] Alocando gerador XML com.apple.dnsSettings.managed...", isSuccess: false)
            try? await Task.sleep(nanoseconds: 180_000_000)

            appendLog("[UUID] PayloadUUID dinâmico gerado para \(preset.title) (\(preset.primaryIP) / \(preset.secondaryIP))", isSuccess: false)
            try? await Task.sleep(nanoseconds: 180_000_000)

            let fileURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("iPhoneSecreto_ZeroDelay_\(preset.id).mobileconfig")

            do {
                guard let data = xml.data(using: .utf8) else {
                    appendLog("[ERRO] Falha na codificação UTF-8 do perfil XML.", isSuccess: false)
                    isInjecting = false
                    return
                }
                try data.write(to: fileURL, options: .atomic)
                generatedFileURL = fileURL
                latestPayloadData = data

                appendLog("[DISK] Arquivo gravado em tmp/\(fileURL.lastPathComponent) (\(data.count) bytes)", isSuccess: true)
                try? await Task.sleep(nanoseconds: 180_000_000)

                startLocalHTTPServer(payloadData: data)
                try? await Task.sleep(nanoseconds: 220_000_000)

                if let url = localProfileURL {
                    appendLog("[HTTP] Servidor local ativo em \(url.absoluteString)", isSuccess: true)
                }

                appendLog("[READY] Perfil pronto! Escolha Share Sheet ou instalação direta em Ajustes -> Perfil Baixado.", isSuccess: true)
                isInjecting = false

                let notify = UINotificationFeedbackGenerator()
                notify.notificationOccurred(.success)

                if openViaShareSheetAfter {
                    showShareSheet = true
                } else {
                    showWebPortalSheet = true
                }
            } catch {
                appendLog("[ERRO] Não foi possível gravar .mobileconfig: \(error.localizedDescription)", isSuccess: false)
                isInjecting = false
            }
        }
    }

    func openProfileInSafari() {
        guard let url = localProfileURL else { return }
        UIApplication.shared.open(url)
    }

    private func startLocalHTTPServer(payloadData: Data) {
        listener?.cancel()
        listener = nil

        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            let nwListener = try NWListener(using: params, on: .any)

            let htmlPage = buildLocalPortalHTML()
            let capturedPayload = payloadData

            nwListener.stateUpdateHandler = { [weak self] state in
                if case .ready = state, let port = nwListener.port?.rawValue {
                    Task { @MainActor [weak self] in
                        self?.activePort = port
                        self?.localProfileURL = URL(string: "http://127.0.0.1:\(port)/iPhoneSecreto.mobileconfig")
                        self?.localPortalURL = URL(string: "http://127.0.0.1:\(port)/")
                    }
                }
            }

            nwListener.newConnectionHandler = { connection in
                connection.start(queue: .global(qos: .userInitiated))
                connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { data, _, _, _ in
                    let requestText = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                    let isConfigRequest = requestText.contains("/iPhoneSecreto.mobileconfig")

                    let responseData: Data
                    if isConfigRequest {
                        let header = "HTTP/1.1 200 OK\r\nContent-Type: application/x-apple-aspen-config\r\nContent-Disposition: attachment; filename=\"iPhoneSecreto_ZeroDelay.mobileconfig\"\r\nContent-Length: \(capturedPayload.count)\r\nConnection: close\r\n\r\n"
                        var combined = Data(header.utf8)
                        combined.append(capturedPayload)
                        responseData = combined
                    } else {
                        let htmlData = Data(htmlPage.utf8)
                        let header = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: \(htmlData.count)\r\nConnection: close\r\n\r\n"
                        var combined = Data(header.utf8)
                        combined.append(htmlData)
                        responseData = combined
                    }

                    connection.send(content: responseData, completion: .contentProcessed { _ in
                        connection.cancel()
                    })
                }
            }

            nwListener.start(queue: .global(qos: .userInitiated))
            listener = nwListener
        } catch {
            appendLog("[HTTP] Erro ao iniciar servidor local: \(error.localizedDescription)", isSuccess: false)
        }
    }

    private func buildLocalPortalHTML() -> String {
        """
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>iPhone Secreto — Perfil DNS</title>
          <style>
            body { background:#000; color:#fff; font-family:-apple-system,sans-serif; padding:24px; margin:0; }
            .card { background:#141418; border:1px solid #2e2e3a; border-radius:16px; padding:20px; }
            h1 { font-size:18px; color:#30D158; margin:0 0 8px 0; }
            p { font-size:14px; color:#a2a6b4; line-height:1.45; }
            .btn { display:block; text-align:center; background:#0A84FF; color:#fff; text-decoration:none; font-weight:700; padding:14px; border-radius:12px; margin-top:16px; }
            .tag { font-family:ui-monospace,monospace; font-size:12px; color:#30D158; margin-top:12px; }
          </style>
        </head>
        <body>
          <div class="card">
            <h1>iPHONE SECRETO • Servidor Local</h1>
            <p>Perfil <strong>\(selectedDNS.title) (\(selectedDNS.primaryIP) / \(selectedDNS.secondaryIP))</strong> pronto para instalação no iOS.</p>
            <a class="btn" href="/iPhoneSecreto.mobileconfig">BAIXAR PERFIL (.mobileconfig)</a>
            <p class="tag">Após permitir o download no Safari, abra Ajustes &gt; Perfil Baixado &gt; Instalar.</p>
          </div>
        </body>
        </html>
        """
    }

    private func appendLog(_ message: String, isSuccess: Bool) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        let entry = ConsoleLogEntry(
            timestamp: formatter.string(from: Date()),
            message: message,
            isSuccess: isSuccess
        )
        consoleLogs.append(entry)
    }
}

struct ActivityShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct LocalConfigWebView: UIViewRepresentable {
    let url: URL
    let onProfileDownloadRequested: (URL) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onProfileDownloadRequested: onProfileDownloadRequested)
    }

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.navigationDelegate = context.coordinator
        webView.load(URLRequest(url: url))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        if uiView.url != url {
            uiView.load(URLRequest(url: url))
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let onProfileDownloadRequested: (URL) -> Void

        init(onProfileDownloadRequested: @escaping (URL) -> Void) {
            self.onProfileDownloadRequested = onProfileDownloadRequested
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            if let targetURL = navigationAction.request.url,
               targetURL.lastPathComponent.hasSuffix(".mobileconfig") {
                onProfileDownloadRequested(targetURL)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}
