import Foundation

struct SecurityVerificationResult: Equatable {
    let isValid: Bool
    let actualBundleIdentifier: String
    let actualDisplayName: String
    let failureReasons: [String]
}

enum SecurityGuard {
    static let expectedBundleIdentifier = CyberCredits.expectedBundleID
    static let expectedDisplayName = CyberCredits.expectedDisplayName

    static func verifyIntegrity() -> SecurityVerificationResult {
        let actualBundleID = Bundle.main.bundleIdentifier ?? "<desconhecido>"
        let actualDisplayName = (Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String)
            ?? (Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String)
            ?? "<desconhecido>"

        var reasons: [String] = []

        if actualBundleID != expectedBundleIdentifier {
            reasons.append("Bundle Identifier inválido: esperado '\(expectedBundleIdentifier)', encontrado '\(actualBundleID)'.")
        }

        if actualDisplayName != expectedDisplayName {
            reasons.append("CFBundleDisplayName alterado: esperado '\(expectedDisplayName)', encontrado '\(actualDisplayName)'.")
        }

        return SecurityVerificationResult(
            isValid: reasons.isEmpty,
            actualBundleIdentifier: actualBundleID,
            actualDisplayName: actualDisplayName,
            failureReasons: reasons
        )
    }
}
