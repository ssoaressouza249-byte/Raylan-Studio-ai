import SwiftUI

@main
struct iPhoneSecretoApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @State private var verification = SecurityGuard.verifyIntegrity()

    var body: some Scene {
        WindowGroup {
            Group {
                if verification.isValid {
                    MainTabView()
                } else {
                    TamperLockView(verification: verification)
                }
            }
            .preferredColorScheme(.dark)
            .onChange(of: scenePhase) { newPhase in
                if newPhase == .active {
                    verification = SecurityGuard.verifyIntegrity()
                }
            }
        }
    }
}
