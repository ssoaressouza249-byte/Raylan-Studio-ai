import SwiftUI

enum CyberCredits {
    static let bannerText = "iPHONE SECRETO — Criado por Raylan (GitHub: ssoaressouza249-byte)"
    static let expectedBundleID = "com.raylan.iphonesecreto"
    static let expectedDisplayName = "iPhone Secreto"
}

enum CyberTheme {
    static let background = Color(red: 0.0, green: 0.0, blue: 0.0) // #000000
    static let cardBackground = Color(red: 20.0 / 255.0, green: 20.0 / 255.0, blue: 24.0 / 255.0) // #141418
    static let surfaceElevated = Color(red: 30.0 / 255.0, green: 30.0 / 255.0, blue: 38.0 / 255.0)
    static let border = Color(red: 46.0 / 255.0, green: 46.0 / 255.0, blue: 58.0 / 255.0)
    static let iosBlue = Color(red: 10.0 / 255.0, green: 132.0 / 255.0, blue: 255.0 / 255.0) // #0A84FF
    static let neonGreen = Color(red: 48.0 / 255.0, green: 209.0 / 255.0, blue: 88.0 / 255.0) // #30D158
    static let warningOrange = Color(red: 255.0 / 255.0, green: 159.0 / 255.0, blue: 10.0 / 255.0)
    static let dangerRed = Color(red: 255.0 / 255.0, green: 69.0 / 255.0, blue: 58.0 / 255.0)
    static let tamperBackground = Color(red: 155.0 / 255.0, green: 10.0 / 255.0, blue: 22.0 / 255.0)
    static let textPrimary = Color.white
    static let textSecondary = Color(red: 162.0 / 255.0, green: 166.0 / 255.0, blue: 180.0 / 255.0)
}

struct CyberCard<Content: View>: View {
    var borderColor: Color = CyberTheme.border
    @ViewBuilder let content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(CyberTheme.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(borderColor, lineWidth: 1)
        )
    }
}

struct CyberSectionTitle: View {
    let title: String
    let subtitle: String?
    let systemImage: String
    var accent: Color = CyberTheme.iosBlue

    init(
        _ title: String,
        subtitle: String? = nil,
        systemImage: String,
        accent: Color = CyberTheme.iosBlue
    ) {
        self.title = title
        self.subtitle = subtitle
        self.systemImage = systemImage
        self.accent = accent
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: systemImage)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(accent)
                .frame(width: 30, height: 30)
                .background(accent.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(CyberTheme.textPrimary)
                if let subtitle {
                    Text(subtitle)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(CyberTheme.textSecondary)
                }
            }
        }
    }
}
