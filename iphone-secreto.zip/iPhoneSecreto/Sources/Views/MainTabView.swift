import SwiftUI

struct MainTabView: View {
    @StateObject private var diagnostics = DeviceDiagnosticsService()
    @StateObject private var mobileConfigService = MobileConfigService()

    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(red: 20.0 / 255.0, green: 20.0 / 255.0, blue: 24.0 / 255.0, alpha: 1.0)
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }

    var body: some View {
        VStack(spacing: 0) {
            CyberHeaderBar()

            TabView {
                OptimizationTabView(diagnostics: diagnostics)
                    .tabItem {
                        Label("Otimização", systemImage: "cpu.fill")
                    }

                MobileConfigTabView(configService: mobileConfigService)
                    .tabItem {
                        Label("DNS Perfil", systemImage: "network")
                    }

                AimCalibratorTabView()
                    .tabItem {
                        Label("Mira & Capa", systemImage: "scope")
                    }
            }
            .tint(CyberTheme.neonGreen)
        }
        .background(CyberTheme.background.ignoresSafeArea())
        .preferredColorScheme(.dark)
    }
}
