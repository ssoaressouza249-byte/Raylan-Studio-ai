import SwiftUI

struct OptimizationTabView: View {
    @ObservedObject var diagnostics: DeviceDiagnosticsService

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                telemetrySection
                optimizerActionSection
                hiddenSettingsChecklistSection
                CyberFooterBar()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(CyberTheme.background)
        .onAppear {
            diagnostics.refreshAll()
        }
    }

    private var telemetrySection: some View {
        CyberCard(borderColor: CyberTheme.iosBlue.opacity(0.45)) {
            HStack {
                CyberSectionTitle(
                    "Diagnóstico Real do iPhone",
                    subtitle: "\(diagnostics.deviceModelName) • \(diagnostics.systemVersionString)",
                    systemImage: "waveform.path.ecg",
                    accent: CyberTheme.iosBlue
                )
                Spacer()
                Button {
                    diagnostics.refreshAll()
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(CyberTheme.iosBlue)
                        .frame(width: 34, height: 34)
                        .background(CyberTheme.iosBlue.opacity(0.15))
                        .clipShape(Circle())
                }
                .accessibilityLabel("Atualizar diagnóstico")
            }

            LazyVGrid(
                columns: [
                    GridItem(.flexible(), spacing: 10),
                    GridItem(.flexible(), spacing: 10)
                ],
                spacing: 10
            ) {
                MetricTile(
                    icon: "thermometer.medium",
                    title: "Estado Térmico",
                    value: diagnostics.thermalState.title,
                    accent: diagnostics.thermalState.badgeColor
                )

                MetricTile(
                    icon: diagnostics.isLowPowerModeEnabled ? "battery.25" : "battery.100",
                    title: "Bateria & Energia",
                    value: batterySummaryText,
                    accent: diagnostics.isLowPowerModeEnabled ? CyberTheme.warningOrange : CyberTheme.neonGreen
                )
            }

            VStack(spacing: 10) {
                UsageProgressRow(
                    icon: "memorychip",
                    title: "Memória RAM Ativa",
                    detail: "\(diagnostics.formattedUsedMemory) / \(diagnostics.formattedTotalMemory) (App: \(diagnostics.formattedAppFootprint))",
                    fraction: diagnostics.memoryUsedFraction,
                    accent: diagnostics.memoryUsedFraction > 0.85 ? CyberTheme.warningOrange : CyberTheme.iosBlue
                )

                UsageProgressRow(
                    icon: "internaldrive",
                    title: "Espaço em Disco",
                    detail: "Livre: \(diagnostics.formattedFreeDisk) de \(diagnostics.formattedTotalDisk)",
                    fraction: diagnostics.diskUsedFraction,
                    accent: CyberTheme.neonGreen
                )
            }
            .padding(.top, 4)
        }
    }

    private var batterySummaryText: String {
        let levelPart: String
        if let pct = diagnostics.batteryPercent {
            levelPart = "\(pct)% (\(diagnostics.batteryStateLabel))"
        } else {
            levelPart = "Simulador / N/D"
        }
        let powerMode = diagnostics.isLowPowerModeEnabled ? "Pouca Energia: ATIVO" : "Pouca Energia: OFF"
        return "\(levelPart) • \(powerMode)"
    }

    private var optimizerActionSection: some View {
        CyberCard(borderColor: CyberTheme.neonGreen.opacity(0.45)) {
            CyberSectionTitle(
                "Motor de Otimização Total",
                subtitle: "Limpa URLCache, buffers temporários e recalibra leitura de RAM",
                systemImage: "bolt.shield.fill",
                accent: CyberTheme.neonGreen
            )

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(diagnostics.optimizationStatusText)
                        .font(.system(size: 12, weight: .semibold, design: .monospaced))
                        .foregroundColor(CyberTheme.textSecondary)
                    Spacer()
                    Text("\(Int(diagnostics.optimizationProgress * 100))%")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundColor(CyberTheme.neonGreen)
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(CyberTheme.surfaceElevated)
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [CyberTheme.iosBlue, CyberTheme.neonGreen],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(width: max(0, geo.size.width * diagnostics.optimizationProgress))
                            .animation(.easeInOut(duration: 0.2), value: diagnostics.optimizationProgress)
                    }
                }
                .frame(height: 10)
            }

            if let summary = diagnostics.lastOptimizationSummary {
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(CyberTheme.neonGreen)
                    Text(summary)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(CyberTheme.neonGreen)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(CyberTheme.neonGreen.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }

            Button {
                diagnostics.runFullOptimization()
            } label: {
                HStack(spacing: 8) {
                    if diagnostics.isOptimizing {
                        ProgressView()
                            .tint(.black)
                    } else {
                        Image(systemName: "flame.fill")
                            .font(.system(size: 15, weight: .bold))
                    }
                    Text(diagnostics.isOptimizing ? "OTIMIZANDO IPHONE..." : "OTIMIZAR IPHONE COMPLETO")
                        .font(.system(size: 14, weight: .black, design: .monospaced))
                }
                .foregroundColor(.black)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    LinearGradient(
                        colors: [CyberTheme.neonGreen, CyberTheme.iosBlue],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .disabled(diagnostics.isOptimizing)
        }
    }

    private var hiddenSettingsChecklistSection: some View {
        CyberCard {
            HStack {
                CyberSectionTitle(
                    "Checklist de Ajustes Ocultos iOS",
                    subtitle: "Marque os ajustes aplicados no sistema",
                    systemImage: "checklist",
                    accent: CyberTheme.iosBlue
                )
                Spacer()
                Button {
                    diagnostics.openSystemSettings()
                } label: {
                    Text("Ajustes")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(CyberTheme.iosBlue)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(CyberTheme.iosBlue.opacity(0.15))
                        .clipShape(Capsule())
                }
            }

            VStack(spacing: 10) {
                ForEach(diagnostics.checklistItems) { item in
                    Button {
                        diagnostics.toggleChecklistItem(item.id)
                    } label: {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(item.isCompleted ? CyberTheme.neonGreen : CyberTheme.textSecondary)
                                .padding(.top, 2)

                            VStack(alignment: .leading, spacing: 4) {
                                HStack(spacing: 6) {
                                    Text(item.title)
                                        .font(.system(size: 13, weight: .bold))
                                        .foregroundColor(CyberTheme.textPrimary)
                                        .multilineTextAlignment(.leading)

                                    if let detected = item.systemDetectedEnabled {
                                        Text(detected ? "DETECTADO" : "PENDENTE")
                                            .font(.system(size: 9, weight: .black, design: .monospaced))
                                            .foregroundColor(detected ? CyberTheme.neonGreen : CyberTheme.warningOrange)
                                            .padding(.horizontal, 6)
                                            .padding(.vertical, 2)
                                            .background((detected ? CyberTheme.neonGreen : CyberTheme.warningOrange).opacity(0.16))
                                            .clipShape(Capsule())
                                    }
                                }

                                Text(item.pathDescription)
                                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                                    .foregroundColor(CyberTheme.iosBlue)
                                    .multilineTextAlignment(.leading)

                                Text(item.detail)
                                    .font(.system(size: 11, weight: .regular))
                                    .foregroundColor(CyberTheme.textSecondary)
                                    .multilineTextAlignment(.leading)
                            }

                            Spacer(minLength: 0)
                        }
                        .padding(12)
                        .background(CyberTheme.surfaceElevated)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(item.isCompleted ? CyberTheme.neonGreen.opacity(0.5) : CyberTheme.border, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

private struct MetricTile: View {
    let icon: String
    let title: String
    let value: String
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(accent)
                Text(title)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(CyberTheme.textSecondary)
            }
            Text(value)
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(CyberTheme.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(12)
        .frame(maxWidth: .infinity, minHeight: 74, alignment: .topLeading)
        .background(CyberTheme.surfaceElevated)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(accent.opacity(0.35), lineWidth: 1)
        )
    }
}

private struct UsageProgressRow: View {
    let icon: String
    let title: String
    let detail: String
    let fraction: Double
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(accent)
                Text(title)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(CyberTheme.textPrimary)
                Spacer()
                Text("\(Int(fraction * 100))%")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundColor(accent)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(CyberTheme.background)
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(accent)
                        .frame(width: max(0, geo.size.width * fraction))
                }
            }
            .frame(height: 6)

            Text(detail)
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundColor(CyberTheme.textSecondary)
        }
        .padding(10)
        .background(CyberTheme.surfaceElevated)
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}
