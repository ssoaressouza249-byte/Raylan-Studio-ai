import SwiftUI
import UIKit

struct AimCalibratorTabView: View {
    @State private var selectedModel: IPhoneModelPreset = .iphone14_15_16ProMax
    @State private var copiedNotification: Bool = false

    // Simulador de Puxada de Capa
    @State private var dragPoints: [CGPoint] = []
    @State private var dragStartTime: Date? = nil
    @State private var lastVelocityPxPerSec: Double = 0
    @State private var lastShotResult: String = "Arraste para cima na área tática"
    @State private var lastShotColor: Color = CyberTheme.textSecondary
    @State private var totalAttempts: Int = 0
    @State private var perfectHeadshots: Int = 0
    @State private var didTriggerMidHaptic: Bool = false

    private var spec: AimCalibrationSpec {
        selectedModel.calibration
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                modelSelectorCard
                calibrationSpecsCard
                copyButtonCard
                capaSimulatorCard
                CyberFooterBar()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(CyberTheme.background)
    }

    private var modelSelectorCard: some View {
        CyberCard(borderColor: CyberTheme.iosBlue.opacity(0.45)) {
            CyberSectionTitle(
                "Calibrador iOS & Mira Leve",
                subtitle: "Selecione seu iPhone para gerar ajustes exatos",
                systemImage: "scope",
                accent: CyberTheme.iosBlue
            )

            LazyVGrid(
                columns: [
                    GridItem(.flexible(), spacing: 8),
                    GridItem(.flexible(), spacing: 8)
                ],
                spacing: 8
            ) {
                ForEach(IPhoneModelPreset.allCases) { model in
                    let isSelected = selectedModel == model
                    Button {
                        selectedModel = model
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(model.displayName)
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(isSelected ? .black : CyberTheme.textPrimary)
                                .lineLimit(2)
                                .minimumScaleFactor(0.85)
                            Text(model.screenSpecBadge)
                                .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                .foregroundColor(isSelected ? Color.black.opacity(0.78) : CyberTheme.textSecondary)
                                .lineLimit(1)
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, minHeight: 58, alignment: .leading)
                        .background(isSelected ? CyberTheme.neonGreen : CyberTheme.surfaceElevated)
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .stroke(isSelected ? CyberTheme.neonGreen : CyberTheme.border, lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var calibrationSpecsCard: some View {
        VStack(spacing: 12) {
            CyberCard {
                CyberSectionTitle(
                    "Cursor Móvel & Controle Assistivo",
                    subtitle: "Ajustes > Acessibilidade > Controle Assistivo",
                    systemImage: "cursorarrow.motionlines",
                    accent: CyberTheme.neonGreen
                )

                SpecRow("Modo de Seleção (Cursor Móvel)", value: spec.cursorSelectionMode, accent: CyberTheme.neonGreen)
                SpecRow("Velocidade do Cursor Móvel", value: "\(spec.cursorSpeed)", accent: CyberTheme.neonGreen)
                Divider().background(CyberTheme.border)
                SpecRow("Ciclos", value: "\(spec.assistiveCycles)", accent: CyberTheme.iosBlue)
                SpecRow("Repetição de Movimento", value: spec.moveRepeatSeconds, accent: CyberTheme.iosBlue)
                SpecRow("Pressão Longa", value: spec.longPressSeconds, accent: CyberTheme.iosBlue)
                SpecRow("Duração do Toque", value: spec.tapDurationSeconds, accent: CyberTheme.iosBlue)
                SpecRow("Tolerância de Movimento", value: spec.movementTolerance, accent: CyberTheme.iosBlue)
            }

            CyberCard {
                CyberSectionTitle(
                    "Adaptações de Toque",
                    subtitle: "Ajustes > Acessibilidade > Toque > Adaptações de Toque",
                    systemImage: "hand.tap.fill",
                    accent: CyberTheme.iosBlue
                )

                SpecRow("Duração do Pressionar", value: spec.touchHoldDuration, accent: CyberTheme.iosBlue)
                SpecRow("Ignorar Repetição", value: spec.ignoreRepeat, accent: CyberTheme.iosBlue)
                SpecRow("Assistência de Toque", value: spec.touchAssistance, accent: CyberTheme.neonGreen)
            }

            CyberCard(borderColor: CyberTheme.neonGreen.opacity(0.4)) {
                CyberSectionTitle(
                    "Sensibilidade Free Fire (Escala 200)",
                    subtitle: "Calibrada para \(spec.modelName)",
                    systemImage: "target",
                    accent: CyberTheme.neonGreen
                )

                LazyVGrid(
                    columns: [
                        GridItem(.flexible(), spacing: 8),
                        GridItem(.flexible(), spacing: 8),
                        GridItem(.flexible(), spacing: 8)
                    ],
                    spacing: 8
                ) {
                    SensitivityBadge(label: "Geral", value: "\(spec.ffGeral)")
                    SensitivityBadge(label: "Ponto Verm.", value: "\(spec.ffRedDot)")
                    SensitivityBadge(label: "Mira 2x", value: "\(spec.ffMira2x)")
                    SensitivityBadge(label: "Mira 4x", value: "\(spec.ffMira4x)")
                    SensitivityBadge(label: "Mira AWM", value: "\(spec.ffMiraAWM)")
                    SensitivityBadge(label: "Olhadinha", value: "\(spec.ffOlhadinha)")
                }

                SpecRow("Tamanho do Botão de Disparo", value: "\(spec.fireButtonSizePercent)%", accent: CyberTheme.neonGreen)
            }
        }
    }

    private var copyButtonCard: some View {
        Button {
            UIPasteboard.general.string = spec.exportText()
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            withAnimation(.easeInOut(duration: 0.2)) {
                copiedNotification = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                withAnimation(.easeInOut(duration: 0.2)) {
                    copiedNotification = false
                }
            }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: copiedNotification ? "checkmark.circle.fill" : "doc.on.doc.fill")
                    .font(.system(size: 15, weight: .bold))
                Text(copiedNotification ? "CÓDIGO DE MIRA COPIADO!" : "COPIAR TODA A CALIBRAÇÃO COM 1 TOQUE")
                    .font(.system(size: 13, weight: .black, design: .monospaced))
            }
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(copiedNotification ? CyberTheme.neonGreen : CyberTheme.iosBlue)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    private var capaSimulatorCard: some View {
        CyberCard(borderColor: CyberTheme.iosBlue.opacity(0.5)) {
            HStack {
                CyberSectionTitle(
                    "Simulador de Puxada de Capa",
                    subtitle: "Com feedback tátil real (Taptic Engine)",
                    systemImage: "iphone.radiowaves.left.and.right",
                    accent: CyberTheme.neonGreen
                )
                Spacer()
                Text("\(perfectHeadshots)/\(totalAttempts) CAPA")
                    .font(.system(size: 11, weight: .black, design: .monospaced))
                    .foregroundColor(CyberTheme.neonGreen)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(CyberTheme.neonGreen.opacity(0.15))
                    .clipShape(Capsule())
            }

            HStack {
                Text(lastShotResult)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundColor(lastShotColor)
                Spacer()
                Text(String(format: "%.0f px/s", lastVelocityPxPerSec))
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundColor(CyberTheme.iosBlue)
            }

            GeometryReader { geo in
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.black)

                    // Zona alvo (cabeça)
                    VStack {
                        HStack {
                            Spacer()
                            HStack(spacing: 6) {
                                Image(systemName: "scope")
                                    .font(.system(size: 14, weight: .bold))
                                Text("ZONA DE CAPA IDEAL")
                                    .font(.system(size: 10, weight: .black, design: .monospaced))
                            }
                            .foregroundColor(CyberTheme.neonGreen)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(CyberTheme.neonGreen.opacity(0.15))
                            .clipShape(Capsule())
                            Spacer()
                        }
                        .padding(.top, 16)

                        Spacer()

                        // Botão simulado de disparo
                        Circle()
                            .stroke(CyberTheme.iosBlue, lineWidth: 2)
                            .background(Circle().fill(CyberTheme.iosBlue.opacity(0.16)))
                            .overlay(
                                Image(systemName: "arrow.up")
                                    .font(.system(size: 20, weight: .black))
                                    .foregroundColor(.white)
                            )
                            .frame(width: 58, height: 58)
                            .padding(.bottom, 18)
                    }

                    // Trilha do dedo
                    Path { path in
                        guard let first = dragPoints.first else { return }
                        path.move(to: first)
                        for point in dragPoints.dropFirst() {
                            path.addLine(to: point)
                        }
                    }
                    .stroke(
                        LinearGradient(
                            colors: [CyberTheme.iosBlue, CyberTheme.neonGreen],
                            startPoint: .bottom,
                            endPoint: .top
                        ),
                        style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round)
                    )
                }
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(lastShotColor.opacity(0.5), lineWidth: 1.5)
                )
                .contentShape(Rectangle())
                .highPriorityGesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            if dragStartTime == nil {
                                dragStartTime = Date()
                                dragPoints = [value.location]
                                didTriggerMidHaptic = false
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            } else {
                                dragPoints.append(value.location)
                                let dy = (dragPoints.first?.y ?? value.location.y) - value.location.y
                                if dy > geo.size.height * 0.25 && !didTriggerMidHaptic {
                                    didTriggerMidHaptic = true
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                }
                            }
                        }
                        .onEnded { value in
                            evaluateDrag(endLocation: value.location)
                            dragStartTime = nil
                            didTriggerMidHaptic = false
                        }
                )
            }
            .frame(height: 230)

            Text("Faixa ideal para \(spec.modelName): \(Int(spec.idealDragSpeedRange.lowerBound))–\(Int(spec.idealDragSpeedRange.upperBound)) px/s em puxada vertical reta.")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(CyberTheme.textSecondary)
        }
    }

    private func evaluateDrag(endLocation: CGPoint) {
        guard let start = dragPoints.first, let startTime = dragStartTime else { return }
        let elapsed = max(0.02, Date().timeIntervalSince(startTime))
        let upwardDistance = Double(start.y - endLocation.y)
        let horizontalDrift = abs(Double(endLocation.x - start.x))
        let velocity = upwardDistance / elapsed

        lastVelocityPxPerSec = max(0, velocity)
        totalAttempts += 1

        if upwardDistance < 35 {
            lastShotResult = "PUXADA CURTA — Arraste do botão até o topo"
            lastShotColor = CyberTheme.warningOrange
            UIImpactFeedbackGenerator(style: .soft).impactOccurred()
        } else if horizontalDrift > upwardDistance * 0.65 {
            lastShotResult = "DESVIO LATERAL — Puxe mais reto na vertical"
            lastShotColor = CyberTheme.warningOrange
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
        } else if spec.idealDragSpeedRange.contains(velocity) {
            perfectHeadshots += 1
            lastShotResult = "CAPA PERFEITO! MIRA TRAVADA NA CABEÇA"
            lastShotColor = CyberTheme.neonGreen
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } else if velocity > spec.idealDragSpeedRange.upperBound {
            lastShotResult = "MIRA PASSOU DA CABEÇA — Reduza a velocidade"
            lastShotColor = CyberTheme.dangerRed
            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
        } else {
            lastShotResult = "MIRA PRESA NO PEITO — Puxe com mais velocidade"
            lastShotColor = CyberTheme.iosBlue
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        }
    }
}

private struct SpecRow: View {
    let label: String
    let value: String
    let accent: Color

    init(_ label: String, value: String, accent: Color = CyberTheme.iosBlue) {
        self.label = label
        self.value = value
        self.accent = accent
    }

    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            Text(label)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(CyberTheme.textSecondary)
            Spacer()
            Text(value)
                .font(.system(size: 12, weight: .bold, design: .monospaced))
                .foregroundColor(accent)
                .multilineTextAlignment(.trailing)
        }
        .padding(.vertical, 2)
    }
}

private struct SensitivityBadge: View {
    let label: String
    let value: String

    var body: some View {
        VStack(spacing: 4) {
            Text(label)
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(CyberTheme.textSecondary)
                .lineLimit(1)
            Text(value)
                .font(.system(size: 16, weight: .black, design: .monospaced))
                .foregroundColor(CyberTheme.neonGreen)
        }
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity)
        .background(CyberTheme.surfaceElevated)
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .stroke(CyberTheme.border, lineWidth: 1)
        )
    }
}
