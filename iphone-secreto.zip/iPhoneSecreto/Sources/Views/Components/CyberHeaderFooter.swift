import SwiftUI

struct CyberHeaderBar: View {
    var body: some View {
        VStack(spacing: 6) {
            HStack(spacing: 8) {
                Image(systemName: "cpu.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(CyberTheme.neonGreen)

                Text(CyberCredits.bannerText)
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundColor(CyberTheme.textPrimary)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)

                Spacer(minLength: 4)

                HStack(spacing: 4) {
                    Circle()
                        .fill(CyberTheme.neonGreen)
                        .frame(width: 6, height: 6)
                    Text("PRO")
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .foregroundColor(CyberTheme.neonGreen)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(CyberTheme.neonGreen.opacity(0.15))
                .clipShape(Capsule())
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(CyberTheme.cardBackground)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(CyberTheme.iosBlue.opacity(0.45)),
            alignment: .bottom
        )
    }
}

struct CyberFooterBar: View {
    var body: some View {
        VStack(spacing: 4) {
            Divider()
                .background(CyberTheme.border)
            Text(CyberCredits.bannerText)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundColor(CyberTheme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.top, 6)
                .padding(.bottom, 4)
        }
        .padding(.horizontal, 12)
    }
}
