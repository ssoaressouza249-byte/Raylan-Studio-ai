import SwiftUI
import UIKit

struct MobileConfigTabView: View {
    @ObservedObject var configService: MobileConfigService
    @State private var showXMLPreview: Bool = false
    @State private var copiedXML: Bool = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                dnsSelectorCard
                consoleCard
                injectButtonsCard

                if !configService.generatedXML.isEmpty {
                    xmlInspectorCard
                }

                CyberFooterBar()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
        }
        .background(CyberTheme.background)
        .sheet(isPresented: $configService.showShareSheet) {
            if let fileURL = configService.generatedFileURL {
                ActivityShareSheet(activityItems: [fileURL])
            }
        }
        .sheet(isPresented: $configService.showWebPortalSheet) {
            localPortalModal
        }
    }

    private var dnsSelectorCard: some View {
        CyberCard(borderColor: CyberTheme.iosBlue.opacity(0.45)) {
            CyberSectionTitle(
                "Injetor .mobileconfig (Zero Delay)",
                subtitle: "Gera perfil DNS sobre HTTPS (DoH) nativo do iOS",
                systemImage: "network.badge.shield.half.filled",
                accent: CyberTheme.iosBlue
            )

            VStack(spacing: 10) {
                ForEach(DNSProfilePreset.allCases) { preset in
                    let isSelected = configService.selectedDNS == preset
                    Button {
                        configService.selectedDNS = preset
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: isSelected ? "largecircle.fill.circle" : "circle")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(isSelected ? CyberTheme.neonGreen : CyberTheme.textSecondary)

                            VStack(alignment: .leading, spacing: 3) {
                                Text(preset.title)
                                    .font(.system(size: 14, weight: .bold))
                                    .foregroundColor(CyberTheme.textPrimary)
                                Text(preset.subtitle)
                                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                                    .foregroundColor(isSelected ? CyberTheme.neonGreen : CyberTheme.textSecondary)
                            }

                            Spacer()

                            Text(preset.primaryIP)
                                .font(.system(size: 11, weight: .black, design: .monospaced))
                                .foregroundColor(isSelected ? .black : CyberTheme.iosBlue)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(isSelected ? CyberTheme.neonGreen : CyberTheme.iosBlue.opacity(0.15))
                                .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                        }
                        .padding(12)
                        .background(CyberTheme.surfaceElevated)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(isSelected ? CyberTheme.neonGreen : CyberTheme.border, lineWidth: isSelected ? 1.5 : 1)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var consoleCard: some View {
        CyberCard(borderColor: CyberTheme.neonGreen.opacity(0.35)) {
            CyberSectionTitle(
                "Console de Injeção de Código",
                subtitle: "Payload com.apple.dnsSettings.managed + UUID dinâmico",
                systemImage: "terminal.fill",
                accent: CyberTheme.neonGreen
            )

            VStack(alignment: .leading, spacing: 6) {
                ForEach(configService.consoleLogs) { log in
                    HStack(alignment: .top, spacing: 6) {
                        Text("[\(log.timestamp)]")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundColor(CyberTheme.iosBlue)
                        Text(log.message)
                            .font(.system(size: 11, weight: .medium, design: .monospaced))
                            .foregroundColor(log.isSuccess ? CyberTheme.neonGreen : CyberTheme.textPrimary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.black)
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .stroke(CyberTheme.border, lineWidth: 1)
            )
        }
    }

    private var injectButtonsCard: some View {
        CyberCard {
            Button {
                configService.injectProfile(openViaShareSheetAfter: false)
            } label: {
                HStack(spacing: 8) {
                    if configService.isInjecting {
                        ProgressView()
                            .tint(.white)
                    } else {
                        Image(systemName: "arrow.down.doc.fill")
                            .font(.system(size: 15, weight: .bold))
                    }
                    Text(configService.isInjecting ? "GERANDO .MOBILECONFIG..." : "INJETAR PERFIL DE OTIMIZAÇÃO NO IPHONE")
                        .font(.system(size: 13, weight: .black, design: .monospaced))
                        .multilineTextAlignment(.center)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .padding(.horizontal, 10)
                .background(
                    LinearGradient(
                        colors: [CyberTheme.iosBlue, CyberTheme.neonGreen.opacity(0.85)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .disabled(configService.isInjecting)

            Button {
                if configService.generatedFileURL != nil {
                    configService.showShareSheet = true
                } else {
                    configService.injectProfile(openViaShareSheetAfter: true)
                }
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 14, weight: .bold))
                    Text("EXPORTAR VIA SHARE SHEET (ARQUIVOS / AIRDROP)")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                }
                .foregroundColor(CyberTheme.iosBlue)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(CyberTheme.iosBlue.opacity(0.14))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(CyberTheme.iosBlue.opacity(0.45), lineWidth: 1)
                )
            }
            .disabled(configService.isInjecting)

            Text("Caminho após baixar: Ajustes > Geral > VPN e Gerenciamento de Dispositivo (ou Perfil Baixado) > Instalar.")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(CyberTheme.textSecondary)
        }
    }

    private var xmlInspectorCard: some View {
        CyberCard {
            HStack {
                CyberSectionTitle(
                    "XML .mobileconfig Gerado",
                    subtitle: "Inspecione ou copie o payload XML",
                    systemImage: "chevron.left.forwardslash.chevron.right",
                    accent: CyberTheme.iosBlue
                )
                Spacer()
                Button {
                    UIPasteboard.general.string = configService.generatedXML
                    copiedXML = true
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        copiedXML = false
                    }
                } label: {
                    Text(copiedXML ? "Copiado!" : "Copiar XML")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(copiedXML ? .black : CyberTheme.neonGreen)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(copiedXML ? CyberTheme.neonGreen : CyberTheme.neonGreen.opacity(0.16))
                        .clipShape(Capsule())
                }
            }

            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showXMLPreview.toggle()
                }
            } label: {
                HStack {
                    Text(showXMLPreview ? "Ocultar Código XML" : "Visualizar Código XML Completo")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                    Spacer()
                    Image(systemName: showXMLPreview ? "chevron.up" : "chevron.down")
                }
                .foregroundColor(CyberTheme.textPrimary)
                .padding(10)
                .background(CyberTheme.surfaceElevated)
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            }

            if showXMLPreview {
                ScrollView(.horizontal, showsIndicators: true) {
                    Text(configService.generatedXML)
                        .font(.system(size: 10, weight: .regular, design: .monospaced))
                        .foregroundColor(CyberTheme.neonGreen)
                        .padding(10)
                }
                .frame(maxHeight: 240)
                .background(Color.black)
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
        }
    }

    private var localPortalModal: some View {
        NavigationStack {
            VStack(spacing: 14) {
                if let portalURL = configService.localPortalURL {
                    LocalConfigWebView(url: portalURL) { downloadURL in
                        UIApplication.shared.open(downloadURL)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(CyberTheme.border, lineWidth: 1)
                    )
                }

                VStack(spacing: 10) {
                    Button {
                        configService.openProfileInSafari()
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "safari.fill")
                            Text("INSTALAR DIRETO VIA SAFARI (PERFIL BAIXADO)")
                                .font(.system(size: 12, weight: .black, design: .monospaced))
                        }
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(CyberTheme.neonGreen)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }

                    Button {
                        configService.showWebPortalSheet = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                            configService.showShareSheet = true
                        }
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "square.and.arrow.up")
                            Text("ABRIR SHARE SHEET DO iOS")
                                .font(.system(size: 12, weight: .bold, design: .monospaced))
                        }
                        .foregroundColor(CyberTheme.iosBlue)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(CyberTheme.iosBlue.opacity(0.15))
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                }
            }
            .padding(16)
            .background(CyberTheme.background)
            .navigationTitle("Instalador .mobileconfig")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Fechar") {
                        configService.showWebPortalSheet = false
                    }
                    .foregroundColor(CyberTheme.iosBlue)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
