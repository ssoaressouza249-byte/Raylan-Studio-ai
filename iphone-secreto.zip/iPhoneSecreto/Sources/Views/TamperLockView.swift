import SwiftUI

struct TamperLockView: View {
    let verification: SecurityVerificationResult

    var body: some View {
        ZStack {
            CyberTheme.tamperBackground
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Spacer(minLength: 16)

                Image(systemName: "exclamationmark.shield.fill")
                    .font(.system(size: 72, weight: .bold))
                    .foregroundColor(.white)
                    .padding(20)
                    .background(Color.black.opacity(0.28))
                    .clipShape(Circle())

                Text("ACESSO BLOQUEADO")
                    .font(.system(size: 26, weight: .black, design: .monospaced))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)

                Text("ADULTERAÇÃO DETECTADA NO APLICATIVO")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color.white.opacity(0.95))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.35))
                    .clipShape(Capsule())

                VStack(alignment: .leading, spacing: 10) {
                    Text("A verificação criptográfica de integridade identificou modificação não autorizada na identidade oficial do app.")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.white)

                    Divider()
                        .background(Color.white.opacity(0.3))

                    ForEach(verification.failureReasons, id: \.self) { reason in
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "xmark.octagon.fill")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(.white)
                            Text(reason)
                                .font(.system(size: 12, weight: .semibold, design: .monospaced))
                                .foregroundColor(Color.white.opacity(0.95))
                        }
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.black.opacity(0.38))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.white.opacity(0.35), lineWidth: 1)
                )

                Spacer()

                VStack(spacing: 6) {
                    Text("PROTEÇÃO ANTI-MODIFICAÇÃO ATIVA")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .foregroundColor(Color.white.opacity(0.85))
                    Text(CyberCredits.bannerText)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                }
                .padding(12)
                .frame(maxWidth: .infinity)
                .background(Color.black.opacity(0.42))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .padding(24)
        }
        .interactiveDismissDisabled(true)
    }
}
