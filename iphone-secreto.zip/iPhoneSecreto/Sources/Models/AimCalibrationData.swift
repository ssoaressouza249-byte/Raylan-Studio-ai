import Foundation

enum IPhoneModelPreset: String, CaseIterable, Identifiable {
    case iphone7_8Plus
    case iphoneXR_11
    case iphone12_13
    case iphone14_15_16ProMax

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .iphone7_8Plus: return "iPhone 7 / 8 Plus"
        case .iphoneXR_11: return "iPhone XR / 11"
        case .iphone12_13: return "iPhone 12 / 13"
        case .iphone14_15_16ProMax: return "iPhone 14 / 15 / 16 Pro Max"
        }
    }

    var screenSpecBadge: String {
        switch self {
        case .iphone7_8Plus: return "60Hz LCD • Touch 3D"
        case .iphoneXR_11: return "60Hz Liquid Retina • 120Hz Touch Sample"
        case .iphone12_13: return "60Hz Super Retina XDR OLED"
        case .iphone14_15_16ProMax: return "120Hz ProMotion • Alta Resposta"
        }
    }

    var calibration: AimCalibrationSpec {
        switch self {
        case .iphone7_8Plus:
            return AimCalibrationSpec(
                modelName: displayName,
                cursorSelectionMode: "Refinado",
                cursorSpeed: 118,
                assistiveCycles: 10,
                moveRepeatSeconds: "0.03s",
                longPressSeconds: "0.20s",
                tapDurationSeconds: "0.10s",
                movementTolerance: "Máxima (100%)",
                touchHoldDuration: "0.10s (Desativar se pesar)",
                ignoreRepeat: "0.10s",
                touchAssistance: "Usar Localização do Toque Inicial",
                ffGeral: 196,
                ffRedDot: 188,
                ffMira2x: 192,
                ffMira4x: 198,
                ffMiraAWM: 118,
                ffOlhadinha: 165,
                fireButtonSizePercent: 46,
                idealDragSpeedRange: 520...1450
            )
        case .iphoneXR_11:
            return AimCalibrationSpec(
                modelName: displayName,
                cursorSelectionMode: "Refinado",
                cursorSpeed: 112,
                assistiveCycles: 8,
                moveRepeatSeconds: "0.03s",
                longPressSeconds: "0.20s",
                tapDurationSeconds: "0.10s",
                movementTolerance: "Alta (85%)",
                touchHoldDuration: "0.10s",
                ignoreRepeat: "0.10s",
                touchAssistance: "Usar Localização do Toque Inicial",
                ffGeral: 192,
                ffRedDot: 182,
                ffMira2x: 186,
                ffMira4x: 194,
                ffMiraAWM: 112,
                ffOlhadinha: 158,
                fireButtonSizePercent: 48,
                idealDragSpeedRange: 480...1380
            )
        case .iphone12_13:
            return AimCalibrationSpec(
                modelName: displayName,
                cursorSelectionMode: "Individual",
                cursorSpeed: 106,
                assistiveCycles: 6,
                moveRepeatSeconds: "0.04s",
                longPressSeconds: "0.25s",
                tapDurationSeconds: "0.10s",
                movementTolerance: "Média-Alta (75%)",
                touchHoldDuration: "0.10s",
                ignoreRepeat: "0.10s",
                touchAssistance: "Usar Localização do Toque Final",
                ffGeral: 185,
                ffRedDot: 176,
                ffMira2x: 180,
                ffMira4x: 188,
                ffMiraAWM: 105,
                ffOlhadinha: 150,
                fireButtonSizePercent: 50,
                idealDragSpeedRange: 440...1280
            )
        case .iphone14_15_16ProMax:
            return AimCalibrationSpec(
                modelName: displayName,
                cursorSelectionMode: "Individual",
                cursorSpeed: 98,
                assistiveCycles: 4,
                moveRepeatSeconds: "0.05s",
                longPressSeconds: "0.25s",
                tapDurationSeconds: "0.10s",
                movementTolerance: "Média (65%)",
                touchHoldDuration: "0.10s",
                ignoreRepeat: "0.10s",
                touchAssistance: "Usar Localização do Toque Final",
                ffGeral: 178,
                ffRedDot: 168,
                ffMira2x: 174,
                ffMira4x: 182,
                ffMiraAWM: 96,
                ffOlhadinha: 142,
                fireButtonSizePercent: 52,
                idealDragSpeedRange: 390...1180
            )
        }
    }
}

struct AimCalibrationSpec {
    let modelName: String
    // Cursor Móvel
    let cursorSelectionMode: String
    let cursorSpeed: Int
    // Controle Assistivo
    let assistiveCycles: Int
    let moveRepeatSeconds: String
    let longPressSeconds: String
    let tapDurationSeconds: String
    let movementTolerance: String
    // Adaptações de Toque
    let touchHoldDuration: String
    let ignoreRepeat: String
    let touchAssistance: String
    // Sensibilidade Free Fire (Escala 0-200)
    let ffGeral: Int
    let ffRedDot: Int
    let ffMira2x: Int
    let ffMira4x: Int
    let ffMiraAWM: Int
    let ffOlhadinha: Int
    let fireButtonSizePercent: Int
    let idealDragSpeedRange: ClosedRange<Double>

    func exportText() -> String {
        """
        === iPHONE SECRETO — CALIBRAÇÃO MIRA LEVE ===
        Modelo: \(modelName)

        [CURSOR MÓVEL]
        • Modo de Seleção: \(cursorSelectionMode)
        • Velocidade do Cursor Móvel: \(cursorSpeed)

        [CONTROLE ASSISTIVO]
        • Ciclos: \(assistiveCycles)
        • Repetição de Movimento: \(moveRepeatSeconds)
        • Pressão Longa: \(longPressSeconds)
        • Duração do Toque: \(tapDurationSeconds)
        • Tolerância de Movimento: \(movementTolerance)

        [ADAPTAÇÕES DE TOQUE]
        • Duração do Pressionar: \(touchHoldDuration)
        • Ignorar Repetição: \(ignoreRepeat)
        • Assistência de Toque: \(touchAssistance)

        [SENSIBILIDADE FREE FIRE]
        • Geral: \(ffGeral)
        • Ponto Vermelho: \(ffRedDot)
        • Mira 2x: \(ffMira2x)
        • Mira 4x: \(ffMira4x)
        • Mira AWM: \(ffMiraAWM)
        • Olhadinha: \(ffOlhadinha)
        • Botão de Disparo: \(fireButtonSizePercent)%

        \(CyberCredits.bannerText)
        """
    }
}
