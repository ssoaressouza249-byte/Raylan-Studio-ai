package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = Color(0xFF000000),
        ) { innerPadding ->
          IosProjectCompanionScreen(modifier = Modifier.padding(innerPadding))
        }
      }
    }
  }
}

@Composable
fun IosProjectCompanionScreen(modifier: Modifier = Modifier) {
  val bg = Color(0xFF000000)
  val card = Color(0xFF141418)
  val border = Color(0xFF2E2E3A)
  val iosBlue = Color(0xFF0A84FF)
  val neonGreen = Color(0xFF30D158)

  Column(
    modifier =
      modifier
        .fillMaxSize()
        .background(bg)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = "iPHONE SECRETO — Criado por Raylan (GitHub: ssoaressouza249-byte)",
      color = neonGreen,
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
    )

    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(card, RoundedCornerShape(16.dp))
          .border(1.dp, iosBlue.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
          .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Text(
        text = "Projeto iOS Swift 5.9 / SwiftUI Pronto",
        color = Color.White,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text =
          "Os arquivos nativos do iOS (com.raylan.iphonesecreto) foram gerados na raiz do repositório para compilação automática em macos-latest via XcodeGen + GitHub Actions.",
        color = Color(0xFFA2A6B4),
        fontSize = 13.sp,
      )
    }

    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(card, RoundedCornerShape(16.dp))
          .border(1.dp, border, RoundedCornerShape(16.dp))
          .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Text(
        text = "Arquivos iOS Gerados",
        color = iosBlue,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
      )
      val items =
        listOf(
          "• project.yml (XcodeGen iOS 16.0+, sem assinatura)",
          "• .github/workflows/build-ios.yml (Gera iPhoneSecreto.ipa)",
          "• iPhoneSecreto/Sources/Security/SecurityGuard.swift",
          "• iPhoneSecreto/Sources/Services/DeviceDiagnosticsService.swift",
          "• iPhoneSecreto/Sources/Services/MobileConfigService.swift",
          "• iPhoneSecreto/Sources/Views/OptimizationTabView.swift",
          "• iPhoneSecreto/Sources/Views/MobileConfigTabView.swift",
          "• iPhoneSecreto/Sources/Views/AimCalibratorTabView.swift",
        )
      items.forEach { line ->
        Text(
          text = line,
          color = Color.White,
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    Text(
      text = "iPHONE SECRETO — Criado por Raylan (GitHub: ssoaressouza249-byte)",
      color = Color(0xFFA2A6B4),
      fontSize = 11.sp,
      fontFamily = FontFamily.Monospace,
    )
  }
}
